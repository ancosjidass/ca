"""`.ss` / `.screenshot` / `اسکرین` - turn a replied message into a "phone screenshot" style sticker.

    (reply) .ss            dark bubble with avatar + sender name + time
    (reply) .ss light      light theme
    (reply) .ss quote      also draw the message it replies to
Works in every chat / PV / group. The result is sent as a sticker (WebP) in the same chat.
"""
from __future__ import annotations

import io
import logging
import os
import re
from datetime import timezone
from zoneinfo import ZoneInfo

from telethon import events

from utils.shot import render_message_sticker

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
TIMEZONE = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"


def _name_of(entity) -> str:
    if entity is None:
        return "?"
    parts = [getattr(entity, "first_name", None), getattr(entity, "last_name", None)]
    return " ".join(x for x in parts if x).strip() or getattr(entity, "title", None) or getattr(entity, "username", None) or "?"


def _media_label(m) -> str | None:
    if getattr(m, "photo", None):
        return "[عکس]"
    if getattr(m, "sticker", None):
        return "[استیکر]"
    if getattr(m, "voice", None):
        return "[ویس]"
    if getattr(m, "video_note", None):
        return "[ویدیو مسیج]"
    if getattr(m, "gif", None):
        return "[گیف]"
    if getattr(m, "video", None):
        return "[ویدیو]"
    if getattr(m, "audio", None):
        return "[موزیک]"
    if getattr(m, "document", None):
        return "[فایل]"
    if getattr(m, "poll", None):
        return "[نظرسنجی]"
    return None


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?i)^(?:{re.escape(PREFIX)}(?:ss|screenshot|shot)|اسکرین(?:\s*شات)?)(?:\s+(.+))?$"))
    async def screenshot(event):
        explicit = (event.raw_text or "").lstrip().startswith(PREFIX)
        if not event.is_reply:
            if explicit:
                await event.reply("❌ روی یک پیام Reply کن و بنویس `.ss` (یا `.ss light` / `.ss quote`).")
            return
        args = (event.pattern_match.group(1) or "").lower().split()
        theme = "light" if ("light" in args or "روشن" in args) else "dark"
        with_quote = "quote" in args or "ریپلای" in args
        m = await event.get_reply_message()
        if m is None:
            return
        try:
            await event.edit("📸 …")
        except Exception:  # noqa: BLE001
            pass
        sender = None
        try:
            sender = await m.get_sender()
        except Exception:  # noqa: BLE001
            pass
        avatar = None
        try:
            if sender is not None:
                avatar = await client.download_profile_photo(sender, file=bytes)
        except Exception:  # noqa: BLE001
            avatar = None
        photo = None
        if getattr(m, "photo", None) and not getattr(m, "sticker", None):
            try:
                photo = await client.download_media(m, file=bytes, thumb=-1)
            except Exception:  # noqa: BLE001
                photo = None
        try:
            zone = ZoneInfo(TIMEZONE)
        except Exception:  # noqa: BLE001
            zone = timezone.utc
        when = m.date.astimezone(zone).strftime("%H:%M") if getattr(m, "date", None) else ""
        reply_name = reply_text = None
        if with_quote and getattr(m, "reply_to", None):
            try:
                parent = await m.get_reply_message()
                if parent is not None:
                    reply_name = _name_of(await parent.get_sender())
                    reply_text = parent.message or _media_label(parent) or ""
            except Exception:  # noqa: BLE001
                pass
        try:
            data = render_message_sticker(
                name=_name_of(sender), text=m.message or "", avatar=avatar, time_text=when, theme=theme,
                user_id=int(getattr(sender, "id", 0) or 0), reply_name=reply_name, reply_text=reply_text,
                media_label=_media_label(m), photo=photo,
            )
        except Exception as exc:  # noqa: BLE001
            log.exception("screenshot render failed")
            return await event.edit(f"❌ ساخت اسکرین‌شات ناموفق بود: {exc.__class__.__name__}")
        buf = io.BytesIO(data)
        buf.name = "sticker.webp"
        await client.send_file(event.chat_id, buf, force_document=False, reply_to=m.id)
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass
