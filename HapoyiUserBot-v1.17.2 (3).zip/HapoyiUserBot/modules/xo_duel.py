"""Two-player Tic-Tac-Toe (XO) with inline buttons.

    .xo      open a game in this chat (PV: the other person is the opponent; group: Reply to challenge
             one person, otherwise the first person who presses "Join" becomes the opponent)
Flow: the board starts as a lobby with a "🎮 Join" button. When the opponent presses it (in a PV / Reply challenge only
that one person may join) the game starts and a RANDOM player moves first (owner = ❌, opponent = ⭕).
Also reachable from `.menu` (button) or by typing @YourAssistantBot in any chat. The board message is posted
through the Assistant Bot's inline mode, so the bot does not have to be a member of the chat.
Win/loss statistics are stored in the OWNER's own database (kv key `xo:duel`).
"""
from __future__ import annotations

import logging
import os
import random
import re
import secrets
import time
from dataclasses import dataclass, field
from typing import Any

from telethon import Button, events

from utils.inline_launch import post_inline

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."

LINES = ((0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6))
MARK = {"X": "❌", "O": "⭕", "": "▫️"}
GAME_TTL = 3600


def winner(board: list[str]) -> str | None:
    """'X' / 'O' for a win, 'D' for a draw, None while the game goes on."""
    for a, b, c in LINES:
        if board[a] and board[a] == board[b] == board[c]:
            return board[a]
    return "D" if all(board) else None


@dataclass
class XO:
    token: str
    owner_uid: int
    owner_name: str
    opp_uid: int | None = None
    opp_name: str = ""
    fixed_opp: bool = False
    started: bool = False
    board: list[str] = field(default_factory=lambda: [""] * 9)
    turn: str = "X"
    result: str | None = None
    created: float = field(default_factory=time.time)

    def uid_of(self, mark: str) -> int | None:
        return self.owner_uid if mark == "X" else self.opp_uid

    def start(self, rng: random.Random | None = None) -> str:
        """Both players are in: pick who moves first at random. Returns the mark ('X'/'O') that starts."""
        self.started = True
        self.turn = (rng or random).choice(("X", "O"))
        return self.turn

    def body(self) -> str:
        opp = self.opp_name or "❓ منتظر حریف"
        text = f"❌⭕ <b>XO دو نفره</b>\n❌ {self.owner_name}   vs   ⭕ {opp}\n"
        if not self.started and self.result is None:
            who = f"فقط <b>{self.opp_name}</b>" if self.fixed_opp and self.opp_name else "یک نفر"
            return text + f"\n🕹 منتظر جوین شدن حریف… {who} باید روی «🎮 Join» بزند.\n🎲 بعد از جوین، نفر اول شانسی انتخاب می‌شه."
        if self.result == "D":
            return text + "\n🤝 <b>مساوی!</b>"
        if self.result in ("X", "O"):
            name = self.owner_name if self.result == "X" else self.opp_name
            return text + f"\n🏆 <b>برنده: {MARK[self.result]} {name}</b>"
        if self.result == "cancel":
            return text + "\n🚪 بازی لغو شد."
        who = self.owner_name if self.turn == "X" else (self.opp_name or "حریف")
        note = f"\n🎲 قرعه: <b>{who}</b> شروع می‌کنه!" if self.board.count("") == 9 else ""
        return text + f"{note}\n🎯 نوبت: {MARK[self.turn]} <b>{who}</b>"

    def buttons(self):
        if not self.started and self.result is None:
            return [[Button.inline("🎮 Join", f"xo:{self.token}:j".encode())],
                    [Button.inline("🚪 انصراف (فقط صاحب بازی)", f"xo:{self.token}:x".encode())]]
        rows = [[Button.inline(MARK[self.board[r * 3 + c]], f"xo:{self.token}:{r * 3 + c}".encode()) for c in range(3)] for r in range(3)]
        if self.result is None:
            rows.append([Button.inline("🚪 انصراف (فقط صاحب بازی)", f"xo:{self.token}:x".encode())])
        return rows


GAMES: dict[str, XO] = {}
_bot: Any = None
_fleet: Any = None


def _gc() -> None:
    now = time.time()
    for k in [k for k, g in GAMES.items() if now - g.created > GAME_TTL]:
        GAMES.pop(k, None)


def _display(entity) -> str:
    n = " ".join(x for x in (getattr(entity, "first_name", None), getattr(entity, "last_name", None)) if x)
    return n or getattr(entity, "title", None) or getattr(entity, "username", None) or "؟"


def new_game(owner_uid: int, owner_name: str) -> XO:
    _gc()
    game = XO(secrets.token_urlsafe(6), int(owner_uid), owner_name)
    GAMES[game.token] = game
    return game


async def _record(game: XO) -> None:
    rt = _fleet.runtime_for_user(game.owner_uid) if _fleet is not None else None
    if rt is None:
        return
    stats = await rt.db.get_kv("xo:duel", {"wins": 0, "losses": 0, "draws": 0}) or {}
    key = "draws" if game.result == "D" else "wins" if game.result == "X" else "losses"
    stats[key] = int(stats.get(key, 0)) + 1
    await rt.db.set_kv("xo:duel", stats)


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}xo$"))
    async def xo_cmd(event):
        if _bot is None:
            return await event.reply("❌ برای بازی دو نفره Assistant Bot لازمه (BOT_TOKEN در .env).")
        me = await client.get_me()
        game = new_game(int(me.id), _display(me))
        opponent = None
        if event.is_reply:
            m = await event.get_reply_message()
            opponent = await m.get_sender() if m else None
        elif event.is_private:
            opponent = await event.get_chat()
        if opponent is not None and getattr(opponent, "id", None) and int(opponent.id) != game.owner_uid and not getattr(opponent, "bot", False):
            game.opp_uid, game.opp_name, game.fixed_opp = int(opponent.id), _display(opponent), True
        try:
            await post_inline(client, _bot, f"xo {game.token}", event.chat_id, event.reply_to_msg_id)
        except Exception as exc:  # noqa: BLE001
            log.info("xo inline failed (%s: %s); falling back to bot.send_message", exc.__class__.__name__, exc)
            try:
                await _bot.send_message(event.chat_id, game.body(), parse_mode="html", buttons=game.buttons())
            except Exception as exc2:  # noqa: BLE001
                GAMES.pop(game.token, None)
                return await event.reply(
                    "❌ Assistant Bot نتونست بازی رو بفرسته.\n"
                    "• در @BotFather دستور /setinline بزن و Inline رو برای بات روشن کن، یا\n"
                    f"• بات رو عضو این گروه کن.\n({exc2.__class__.__name__})")
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass


def attach(bot, fleet) -> None:
    global _bot, _fleet
    _bot, _fleet = bot, fleet

    @bot.on(events.InlineQuery(pattern=r"^xo\s+(\S+)$"))
    async def on_inline(event):
        game = GAMES.get(event.pattern_match.group(1))
        if game is None or event.sender_id != game.owner_uid:
            return await event.answer([], cache_time=0)
        await event.answer([event.builder.article("❌⭕ XO دو نفره", text=game.body(), parse_mode="html", buttons=game.buttons(),
                                                  description="شروع بازی دو نفره")], cache_time=0)

    @bot.on(events.CallbackQuery(pattern=rb"xo:.*"))
    async def on_click(event):
        try:
            _, token, key = event.data.decode().split(":", 2)
        except ValueError:
            return await event.answer("دکمهٔ نامعتبر", alert=True)
        game = GAMES.get(token)
        if game is None or game.result is not None:
            return await event.answer("این بازی تموم شده یا منقضی شده.", alert=True)
        uid = int(event.sender_id)
        if key == "x":
            if uid != game.owner_uid:
                return await event.answer("فقط صاحب بازی می‌تونه لغو کنه.", alert=True)
            game.result = "cancel"
            GAMES.pop(token, None)
            return await event.edit(game.body(), parse_mode="html", buttons=game.buttons())
        if key == "j":
            if game.started:
                return await event.answer("بازی شروع شده.", alert=True)
            if uid == game.owner_uid:
                return await event.answer("تو صاحب بازی هستی؛ باید یک نفر دیگه جوین بشه. ⏳", alert=True)
            if game.opp_uid is not None and uid != game.opp_uid:
                return await event.answer("این بازی دو نفره‌ست و حریفش مشخصه. ✋", alert=True)
            if game.opp_uid is None:
                game.opp_uid, game.opp_name = uid, _display(await event.get_sender())
            game.start()
            await event.answer("جوین شدی! 🎲")
            return await event.edit(game.body(), parse_mode="html", buttons=game.buttons())
        if not key.isdigit() or not 0 <= int(key) <= 8:
            return await event.answer("انتخاب نامعتبر", alert=True)
        cell = int(key)
        if not game.started:
            return await event.answer("هنوز حریف جوین نشده؛ منتظر بمون. ⏳", alert=True)
        # who may play?
        if uid == game.owner_uid:
            if game.turn != "X":
                return await event.answer("نوبت حریفه ⏳", alert=True)
        elif uid != game.opp_uid:
            return await event.answer("این بازی دو نفره‌ست و حریفش مشخصه. ✋", alert=True)
        elif game.turn != "O":
            return await event.answer("نوبت تو نیست ⏳", alert=True)
        if game.board[cell]:
            return await event.answer("این خونه پره!", alert=True)
        game.board[cell] = game.turn
        game.result = winner(game.board)
        if game.result is None:
            game.turn = "O" if game.turn == "X" else "X"
        else:
            await _record(game)
            GAMES.pop(token, None)
        await event.answer()
        await event.edit(game.body(), parse_mode="html", buttons=game.buttons())
