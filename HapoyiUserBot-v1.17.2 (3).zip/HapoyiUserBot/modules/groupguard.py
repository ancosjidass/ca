"""Group guard: join captcha, personal black-list, activity report.

    .captcha on [seconds]|off|status     new members must answer a tiny sum in the group (default 90 s) or they are kicked
                                         (needs Ban Users; admins / bots are never asked; they can rejoin)
    .blacklist add [@user|id] [reason]   (or Reply)  remember a user: banned on sight in every group where you can ban
    .blacklist del|list|on|off|sweep     sweep = ban the list right now in every group you administer
    .activity [7d|24h]                   top 10 talkers + busiest hour of this chat in that period
"""
from __future__ import annotations

import asyncio
import logging
import os
import random
import re
from collections import Counter
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from telethon import events
from telethon.errors import FloodWaitError, RPCError

from core.actions import UnsupportedChat, edit_banned
from core.identity import my_id
from core.permissions import can_act_on, clean_target, explain_error, require_group_right, resolve_target
from modules.tagger import mention
from utils.activity import display_name
from utils.formatting import parse_duration
from utils.rights import ban_rights, open_rights

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
DEFAULT_TIMEOUT = 90
MAX_ATTEMPTS = 3
ACTIVITY_SCAN = int(os.getenv("TOP_SCAN_LIMIT", "5000") or 5000)
TABLES = (
    "CREATE TABLE IF NOT EXISTS captcha_chats (chat_id INTEGER PRIMARY KEY, timeout INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS bl_users (user_id INTEGER PRIMARY KEY, name TEXT, reason TEXT, created_at TEXT NOT NULL)",
)


def make_question(rng: random.Random | None = None) -> tuple[str, int]:
    r = rng or random
    a, b = r.randint(2, 9), r.randint(2, 9)
    return f"{a} + {b}", a + b


def setup(client, db):
    ready = {"done": False}
    pending: dict[tuple[int, int], dict] = {}  # (chat, user) -> {answer, qid, tries, task}

    async def ensure() -> None:
        if not ready["done"]:
            ready["done"] = True
            for stmt in TABLES:
                await db.execute(stmt)

    async def kick(chat_id: int, user) -> bool:
        try:
            await edit_banned(client, chat_id, user, ban_rights())
            try:
                await edit_banned(client, chat_id, user, open_rights())  # may rejoin later
            except (RPCError, UnsupportedChat):
                pass
            return True
        except (RPCError, UnsupportedChat) as exc:
            log.info("captcha kick failed in %s: %s", chat_id, exc.__class__.__name__)
            return False

    async def forget(key: tuple[int, int], delete_question: bool = True) -> None:
        info = pending.pop(key, None)
        if info and delete_question:
            try:
                await client.delete_messages(key[0], [info["qid"]])
            except Exception:  # noqa: BLE001
                pass

    async def expire(key: tuple[int, int], user, timeout: int) -> None:
        try:
            await asyncio.sleep(timeout)
        except asyncio.CancelledError:
            return
        if key in pending:
            await forget(key)
            if await kick(key[0], user):
                try:
                    note = await client.send_message(key[0], f"👢 {display_name(user)} جواب نداد و از گروه حذف شد.")
                    await asyncio.sleep(8)
                    await note.delete()
                except Exception:  # noqa: BLE001
                    pass

    # ------------------------------------------------------------------ joins
    @client.on(events.ChatAction)
    async def on_join(event):
        if not (event.user_joined or event.user_added) or not event.is_group:
            return
        await ensure()
        me = await my_id(client)
        chat = int(event.chat_id)
        try:
            users = await event.get_users()
        except Exception:  # noqa: BLE001
            return
        for user in users or []:
            uid = int(user.id)
            if uid == me or getattr(user, "bot", False):
                continue
            can_ban = (await require_group_right(client, chat, "ban_users", fresh=False)).allowed
            if not can_ban:
                continue
            # 1) personal black-list
            if await db.get_kv("bl_auto", True) and await db.fetchone("SELECT 1 FROM bl_users WHERE user_id=?", (uid,)):
                try:
                    await edit_banned(client, chat, user, ban_rights())
                    await client.send_message(chat, f"🚫 {display_name(user)} در بلک‌لیست است و بن شد.")
                except (RPCError, UnsupportedChat):
                    pass
                continue
            # 2) captcha
            cfg = await db.fetchone("SELECT timeout FROM captcha_chats WHERE chat_id=?", (chat,))
            if not cfg:
                continue
            question, answer = make_question()
            timeout = int(cfg["timeout"])
            try:
                msg = await client.send_message(chat, f"👋 {mention(user)} خوش اومدی!\nبرای ماندن در گروه جواب بده: **{question} = ?**\n"
                                                f"(تا {timeout} ثانیه، فقط عدد)", parse_mode="md")
            except RPCError:
                continue
            key = (chat, uid)
            task = asyncio.get_running_loop().create_task(expire(key, user, timeout))
            pending[key] = {"answer": answer, "qid": msg.id, "tries": 0, "task": task}

    @client.on(events.NewMessage(incoming=True))
    async def captcha_answers(event):
        if not pending or not event.is_group or not event.sender_id:
            return
        key = (int(event.chat_id), int(event.sender_id))
        info = pending.get(key)
        if not info:
            return
        text = (event.raw_text or "").strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
        info["tries"] += 1
        right = text.isdigit() and int(text) == info["answer"]
        if right:
            info["task"].cancel()
            await forget(key)
        elif info["tries"] >= MAX_ATTEMPTS:
            info["task"].cancel()
            await forget(key)
            user = await event.get_sender()
            if user is not None:
                await kick(key[0], user)
        # the answer itself is noise: remove it when we may
        if right or info["tries"] >= MAX_ATTEMPTS:
            try:
                await event.delete()
            except Exception:  # noqa: BLE001
                pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}captcha(?:\s+(on|off|status))?(?:\s+(\d+))?$"))
    async def captcha_cmd(event):
        await ensure()
        word = event.pattern_match.group(1) or "status"
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        row = await db.fetchone("SELECT timeout FROM captcha_chats WHERE chat_id=?", (event.chat_id,))
        if word == "status":
            return await event.reply(f"🧩 کپچا: {'ON — ' + str(row['timeout']) + ' ثانیه' if row else 'OFF'}\n`{PREFIX}captcha on [ثانیه]` | `off`")
        if word == "off":
            await db.execute("DELETE FROM captcha_chats WHERE chat_id=?", (event.chat_id,))
            return await event.reply("🧩 کپچا خاموش شد.")
        perm = await require_group_right(client, event.chat_id, "ban_users")
        if not perm.allowed:
            return await event.reply("❌ برای کپچا باید حق Ban Users داشته باشی: " + perm.reason)
        timeout = max(20, min(int(event.pattern_match.group(2) or DEFAULT_TIMEOUT), 600))
        await db.execute("INSERT INTO captcha_chats(chat_id,timeout) VALUES(?,?) ON CONFLICT(chat_id) DO UPDATE SET timeout=excluded.timeout", (event.chat_id, timeout))
        await event.reply(f"🧩 کپچا روشن شد: عضو جدید باید ظرف {timeout} ثانیه جواب یک جمع ساده را بدهد، وگرنه کیک می‌شود.")

    # ------------------------------------------------------------------ black-list
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}blacklist(?:\s+(.*))?$"))
    async def blacklist(event):
        await ensure()
        parts = (event.pattern_match.group(1) or "").split(None, 2)
        word = parts[0].lower() if parts else "list"
        if word in {"on", "off"}:
            await db.set_kv("bl_auto", word == "on")
            return await event.reply("🚫 بن خودکار هنگام ورود " + ("روشن شد." if word == "on" else "خاموش شد."))
        if word == "list":
            rows = await db.fetchall("SELECT user_id,name,reason FROM bl_users ORDER BY created_at")
            if not rows:
                return await event.reply("🚫 بلک‌لیست خالی است.\n" + f"`{PREFIX}blacklist add` (Reply) | `del` | `list` | `on|off` | `sweep`")
            lines = [f"🚫 بلک‌لیست ({len(rows)}) — بن خودکار: {'ON' if await db.get_kv('bl_auto', True) else 'OFF'}"]
            lines += [f"• {r['name'] or '—'} ({r['user_id']})" + (f" — {r['reason']}" if r["reason"] else "") for r in rows[:80]]
            return await event.reply("\n".join(lines)[:3900])
        if word == "sweep":
            rows = await db.fetchall("SELECT user_id FROM bl_users")
            if not rows:
                return await event.reply("🚫 بلک‌لیست خالی است.")
            await event.edit("🧹 در حال بن در گروه‌های تو…")
            groups = bans = 0
            async for d in client.iter_dialogs(limit=300):
                ent = d.entity
                if not getattr(ent, "megagroup", False) or not (getattr(ent, "creator", False) or getattr(ent, "admin_rights", None)):
                    continue
                if not (await require_group_right(client, d.id, "ban_users", fresh=False)).allowed:
                    continue
                groups += 1
                for r in rows:
                    try:
                        await edit_banned(client, d.id, int(r["user_id"]), ban_rights())
                        bans += 1
                    except FloodWaitError as exc:
                        await asyncio.sleep(min(exc.seconds + 1, 60))
                    except (RPCError, UnsupportedChat, ValueError):
                        pass
                    await asyncio.sleep(0.5)
            return await event.edit(f"🚫 تمام شد: {bans} بن در {groups} گروه.")
        if word in {"add", "del", "remove", "rm"}:
            _c = clean_target(parts[1]) if len(parts) > 1 else ""
            explicit = parts[1] if _c.startswith("@") or re.fullmatch(r"-?\d{3,16}", _c) else None
            reason = " ".join(parts[2:] if explicit else parts[1:]).strip()[:120] if len(parts) > 1 else ""
            user = await resolve_target(event, explicit, bare_ok=True)
            if user is None:
                return await event.reply("❌ Reply کن یا @username / id بده.")
            uid = int(user.id)
            if uid == await my_id(client):
                return await event.reply("❌ خودت را نمی‌توانی.")
            if word == "add":
                await db.execute("INSERT INTO bl_users(user_id,name,reason,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET reason=excluded.reason,name=excluded.name",
                                 (uid, display_name(user, str(uid)), reason, datetime.now(timezone.utc).isoformat()))
                msg = f"🚫 {display_name(user)} به بلک‌لیست اضافه شد."
                if event.is_group and (await require_group_right(client, event.chat_id, "ban_users")).allowed and (await can_act_on(client, event.chat_id, user)).allowed:
                    try:
                        await edit_banned(client, event, user, ban_rights())
                        msg += " و در این گروه بن شد."
                    except (RPCError, UnsupportedChat) as exc:
                        msg += f" (بن در این گروه نشد: {explain_error(exc)})"
                    except Exception as exc:  # noqa: BLE001
                        msg += f" (بن در این گروه نشد: {explain_error(exc)})"
                return await event.reply(msg + f"\nبرای بن در همهٔ گروه‌هایت: `{PREFIX}blacklist sweep`")
            n = await db.execute("DELETE FROM bl_users WHERE user_id=?", (uid,))
            return await event.reply("✅ از بلک‌لیست حذف شد (آن‌بن جداگانه با `.unban`)." if n else "ℹ️ در بلک‌لیست نبود.")
        await event.reply(f"فرمت: `{PREFIX}blacklist add|del|list|on|off|sweep`")

    # ------------------------------------------------------------------ activity
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}activity(?:\s+(\S+))?$"))
    async def activity(event):
        try:
            seconds = parse_duration(event.pattern_match.group(1) or "7d")
        except ValueError:
            return await event.reply(f"فرمت: `{PREFIX}activity 7d` یا `24h`")
        since = datetime.now(timezone.utc) - timedelta(seconds=seconds)
        try:
            zone = ZoneInfo(TZ)
        except Exception:  # noqa: BLE001
            zone = timezone.utc
        await event.edit("📈 در حال شمارش…")
        who: Counter = Counter()
        names: dict[int, str] = {}
        hours: Counter = Counter()
        total = 0
        async for m in client.iter_messages(event.chat_id, limit=ACTIVITY_SCAN):
            if m.date and m.date < since:
                break
            if getattr(m, "action", None) or not m.sender_id:
                continue
            total += 1
            who[int(m.sender_id)] += 1
            hours[m.date.astimezone(zone).hour] += 1
            if m.sender_id not in names and getattr(m, "sender", None) is not None:
                names[int(m.sender_id)] = display_name(m.sender, str(m.sender_id))
        if not total:
            return await event.edit("ℹ️ در این بازه پیامی نبود.")
        top = "\n".join(f"{i}. {names.get(u, u)} — {c}" for i, (u, c) in enumerate(who.most_common(10), 1))
        hour, cnt = hours.most_common(1)[0]
        cap = " (به سقف اسکن رسید)" if total >= ACTIVITY_SCAN else ""
        await event.edit(f"📈 فعالیت {event.pattern_match.group(1) or '7d'}: {total} پیام{cap}، {len(who)} نفر\n\n{top}\n\n🕐 شلوغ‌ترین ساعت: {hour:02d}:00 ({cnt} پیام)")
