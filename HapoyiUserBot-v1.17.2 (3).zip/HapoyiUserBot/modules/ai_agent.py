"""AI account control (1.17.0): tell the AI what you want in your own words, it operates the self for you.

    .do <request>                 e.g.  .do هر 5 دقیقه بنویس میو          -> .every 5m میو
                                        .do اتو ریپلای کن: هر کس نوشت علیک بگو سلام   -> .autoreply add علیک => سلام
                                        (Reply on a link)  .do با کیفیت 720 دانلودش کن  -> .dl 720 <link>
                                  (aliases: .act  .agent)
    .ai control on|off|status     the FIRST `.do` asks «اجازهٔ دائمی کنترل اکانت را به من می‌دهی؟» (once); until you answer «بله» nothing runs
    .ai control danger on|off     off (default, 1.17.2): EVERY command runs at once (ban, mute, blacklist, purge ...); on: sensitive ones wait for «بله»
    .ai control log               the last things the AI did for you
    .ai yes | .ai no              the same as writing «بله» / «نه» when something waits for your answer

How it works: the model only PLANS (services/aiagent.py); the bot sends the commands with your account, so every feature of the self
works (downloads with quality, timers, auto-reply, fake actions ...) and every normal rule of each command still applies.
Every command of the self can be sent (1.17.2); only `.do` inside `.do` is refused (endless loop).
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
import re
import time
from collections import deque

from telethon import events
from telethon.errors import FloodWaitError

from core.identity import my_name
from services import aiagent as A
from services import knowledge as K
from services.aithreads import publish

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
GRANT_KEY, DANGER_KEY, LOG_KEY = "ai_ctl_granted", "ai_ctl_danger", "ai_ctl_log"
SETTLE = 0.3  # seconds the handlers of the commands just sent get before answers («بله») are listened to again

USAGE = (f"فرمت: `{PREFIX}do درخواستت به زبان خودت`\n"
         f"مثال: `{PREFIX}do هر ۵ دقیقه بنویس میو` | `{PREFIX}do اتو ریپلای: هر کس نوشت علیک بگو سلام` | (Reply روی لینک) `{PREFIX}do با کیفیت 720 دانلودش کن`\n"
         f"دسترسی: `{PREFIX}ai control on|off|status` | `{PREFIX}ai control log`")

GRANT_TEXT = (
    "🔐 اجازهٔ کنترل اکانت\n\n"
    "برای انجام درخواستت باید دستورهای سلف رو از طرف اکانتت بفرستم (مثل .every ، .dl ، .autoreply ، .fake …) — دقیقاً مثل اینکه خودت تایپ کرده باشی.\n"
    "آیا اجازهٔ دائمی کنترل این اکانت (فقط از راه دستورهای خود سلف) رو به من می‌دی؟\n\n"
    "• دستورهای حساس (بن، پاک‌کردن پیام، ارتقا، اکو …) هر بار قبل از اجرا ازت «بله» می‌خوان.\n"
    "• بعضی دستورها (لایسنس، بکاپ/ریستور، ماکرو …) هیچ‌وقت توسط AI اجرا نمی‌شن.\n"
    f"• هر وقت خواستی: `{PREFIX}ai control off`\n\n"
    f"بنویس «بله» یا «نه» (تا {A.PENDING_TTL // 60} دقیقه) — یا `{PREFIX}ai yes` / `{PREFIX}ai no`.")


def setup(client, db):
    st = {"tasks": set(), "pending": {}, "executing": False, "times": deque(), "sent": deque(maxlen=200)}

    def known() -> set[str]:
        return (K.known_commands() | {"storage", "reply"} | handler_commands()) - set(A.BLOCKED)

    async def granted() -> bool:
        # one-time permission: until the owner answers «بله» (or `.ai control on`) NOTHING is run; every `.do` asks again until then
        return bool(await db.get_kv(GRANT_KEY, False))

    async def danger_on() -> bool:
        return bool(await db.get_kv(DANGER_KEY, False))

    def handler_commands() -> set[str]:
        """Every command that really has a handler in this process (so nothing that exists is ever called «ناشناخته»)."""
        out: set[str] = set()
        try:
            handlers = client.list_event_handlers()
        except Exception:  # noqa: BLE001
            return out
        for _cb, builder in handlers:  # Telethon returns (callback, event)
            pat = getattr(builder, "pattern", None)
            src = getattr(getattr(pat, "__self__", None), "pattern", None) or (pat if isinstance(pat, str) else None)
            if not isinstance(src, str):
                continue
            body = re.sub(r"^(\(\?[a-zA-Z]+\))+", "", src).lstrip("^")
            if not body.startswith(P):
                continue
            body = body[len(P):]
            m = re.match(r"\(\?:([A-Za-z0-9_|]+)\)|([A-Za-z][A-Za-z0-9_]*)", body)
            if not m:
                continue
            for n in (m.group(1) or m.group(2)).split("|"):
                if n:
                    out.add(n.lower())
        return out

    def ask_fn():
        return getattr(client, "_hapoyi_ask_ai", None)

    # ------------------------------------------------------------------ what the AI is told about the replied message (links only, never the text)
    def media_kind(m) -> str:
        for attr, label in (("photo", "photo"), ("video", "video"), ("voice", "voice message"), ("audio", "audio"), ("sticker", "sticker"), ("gif", "gif"), ("document", "file")):
            if getattr(m, attr, None):
                return label
        return "text message"

    async def reply_info(replied):
        if replied is None:
            return None
        try:
            who = await replied.get_sender()
        except Exception:  # noqa: BLE001
            who = None
        name = " ".join(x for x in (getattr(who, "first_name", None), getattr(who, "last_name", None)) if x) or getattr(who, "title", None) or getattr(who, "username", None) or "?"
        return {"kind": media_kind(replied), "who": name, "urls": A.extract_urls(getattr(replied, "message", "") or "")}

    def chat_kind(event) -> str:
        return "private chat" if getattr(event, "is_private", False) else ("group" if getattr(event, "is_group", False) else "channel")

    # ------------------------------------------------------------------ planning
    async def run_request(event, request: str, reply_id, rinfo) -> None:
        now = time.monotonic()
        recent = st["times"]
        while recent and now - recent[0] > 60:
            recent.popleft()
        if len(recent) >= A.MAX_REQUESTS_PER_MIN:
            await event.edit(f"⏳ خیلی سریع شد؛ در هر دقیقه حداکثر {A.MAX_REQUESTS_PER_MIN} درخواست. چند ثانیه صبر کن.")
            return
        recent.append(now)
        ask = ask_fn()
        if ask is None:
            await event.edit("❌ ماژول هوش مصنوعی بارگذاری نشده (`.health`).")
            return
        await event.edit("🤖 …")
        undocumented = tuple(sorted(handler_commands() - K.known_commands() - set(A.BLOCKED)))
        messages = A.build_messages(request, prefix=PREFIX, chat_kind=chat_kind(event), reply_info=rinfo, name=await my_name(client),
                                    extra_commands=undocumented)
        out, err = await ask(messages, max_tokens=900, temperature=0.1)
        if not out:
            await event.edit(err)
            return
        plan = A.parse_plan(out, PREFIX, known(), has_reply=bool(reply_id))
        if plan is None:
            await event.edit("❌ نتونستم درخواستت رو به دستور تبدیل کنم. یک بار دیگه، واضح‌تر بنویس.")
            return
        await handle_plan(event, request, plan, reply_id)

    def rejected_lines(plan: A.Plan) -> str:
        return "\n".join(f"🚫 `{w}` — {why}" for w, why in plan.rejected[:6])

    async def handle_plan(event, request: str, plan: A.Plan, reply_id) -> None:
        head = f"🤖 {request[:80]}"
        if not plan.actions:
            if plan.clarify:
                text = f"❓ {plan.clarify}\n\n(درخواستت رو کامل‌تر با `{PREFIX}do` دوباره بفرست)"
            else:
                text = plan.reply or "🤷 دستوری برای اجرا پیدا نشد."
            if plan.rejected:
                text += "\n\n" + rejected_lines(plan)
            await publish(client, db, event, head, text, kind="do", question=request[:1500])
            return
        if plan.risky and await danger_on():
            st["pending"][event.chat_id] = {"kind": "plan", "event": event, "request": request, "plan": plan, "reply_id": reply_id,
                                            "expires": time.monotonic() + A.PENDING_TTL}
            lines = "\n".join(f"• `{a.text}`" + ("  ⚠️" if a.risky else "") for a in plan.actions)
            text = (f"{plan.reply}\n\n" if plan.reply else "") + f"⚠️ این دستورها حساس‌اند و فقط با تأیید تو اجرا می‌شن:\n{lines}\n\nبنویس «بله» تا اجرا بشه یا «نه» برای لغو (تا {A.PENDING_TTL // 60} دقیقه)."
            if plan.rejected:
                text += "\n\n" + rejected_lines(plan)
            await publish(client, db, event, head, text, kind="do", question=request[:1500])
            return
        await execute(event, request, plan, reply_id)

    # ------------------------------------------------------------------ making the sent command REALLY run
    async def feed_handlers(sent) -> int:
        """Telethon never dispatches the messages this same session sends itself (its own updates are processed but flagged
        `_self_outgoing` = not dispatched). So a command sent with send_message() was just text and no handler ever saw it -
        that is why `.ban` / `.mute` / `.blacklist` typed by the AI did nothing while the same text typed by hand worked.
        Here the sent message is handed to the command handlers exactly like an incoming outgoing-update would be."""
        try:
            handlers = list(client.list_event_handlers())
        except Exception:  # noqa: BLE001
            return 0
        if sent is None or not getattr(sent, "message", None):
            return 0
        try:
            sent.out = True
            ev = events.NewMessage.Event(sent)
            ev._set_client(client)
        except Exception:  # noqa: BLE001
            log.exception("ai control: could not build an event for the sent command")
            return 0
        ran = 0
        for cb, builder in handlers:
            if not isinstance(builder, events.NewMessage) or builder.pattern is None or cb is do_cmd:
                continue
            try:
                if not getattr(builder, "resolved", True):
                    await builder.resolve(client)
                ok = builder.filter(ev)
                if inspect.isawaitable(ok):
                    ok = await ok
            except Exception:  # noqa: BLE001
                continue
            if not ok:
                continue
            ran += 1
            task = asyncio.ensure_future(_run_handler(cb, ev))
            st["tasks"].add(task)
            task.add_done_callback(st["tasks"].discard)
        return ran

    async def _run_handler(cb, ev) -> None:
        try:
            await cb(ev)
        except events.StopPropagation:
            pass
        except Exception:  # noqa: BLE001
            log.exception("ai control: command handler %s failed", getattr(cb, "__name__", cb))

    # ------------------------------------------------------------------ doing
    async def execute(event, request: str, plan: A.Plan, reply_id) -> None:
        done: list[str] = []
        failed: list[tuple[str, str]] = []
        st["executing"] = True
        try:
            for i, a in enumerate(plan.actions):
                if i:
                    await asyncio.sleep(A.SEND_GAP)
                target = "me" if a.chat == "saved" else event.chat_id
                kw = {"link_preview": False, "parse_mode": None}
                if a.on_reply and reply_id and target == event.chat_id:
                    kw["reply_to"] = reply_id
                try:
                    sent = await client.send_message(target, a.text, **kw)
                    st["sent"].append((event.chat_id if target != "me" else None, getattr(sent, "id", None)))
                    await feed_handlers(sent)
                    done.append(a.text)
                except FloodWaitError as exc:
                    failed.append((a.text, f"FloodWait {getattr(exc, 'seconds', '?')}s — بقیه متوقف شد"))
                    break
                except Exception as exc:  # noqa: BLE001
                    log.warning("ai control: sending %r failed: %s", a.text[:60], exc)
                    failed.append((a.text, exc.__class__.__name__))
        finally:
            await asyncio.sleep(SETTLE)
            st["executing"] = False
        entries = list(await db.get_kv(LOG_KEY, []) or [])
        entries.append({"t": int(time.time()), "req": request[:120], "cmds": [c[:100] for c in done][:8]})
        await db.set_kv(LOG_KEY, entries[-50:])
        lines = [plan.reply or "✅ انجام شد."]
        if done:
            lines.append("▶️ از اکانت تو فرستاده شد:\n" + "\n".join(f"• `{c}`" for c in done))
        if failed:
            lines.append("⚠️ انجام نشد:\n" + "\n".join(f"• `{c}` ({why})" for c, why in failed))
        if plan.rejected:
            lines.append(rejected_lines(plan))
        await publish(client, db, event, f"🤖 {request[:80]}", "\n\n".join(lines), kind="do", question=request[:1500])

    # ------------------------------------------------------------------ .do
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}(?:do|act|agent)(?:\s+(.*))?$"))
    async def do_cmd(event):
        request = (event.pattern_match.group(1) or "").strip()
        if not request:
            return await event.reply(USAGE)
        replied = await event.get_reply_message() if event.is_reply else None
        reply_id = getattr(replied, "id", None) if replied is not None else None
        rinfo = await reply_info(replied)
        if not await granted():
            st["pending"][event.chat_id] = {"kind": "grant", "event": event, "request": request, "reply_id": reply_id, "rinfo": rinfo,
                                            "expires": time.monotonic() + A.PENDING_TTL}
            return await event.edit(GRANT_TEXT)
        await run_request(event, request, reply_id, rinfo)

    # ------------------------------------------------------------------ yes / no
    async def resolve(event, yes: bool) -> bool:
        pend = st["pending"].pop(event.chat_id, None)
        if not pend or time.monotonic() > pend["expires"]:
            return False
        origin = pend["event"]
        if not yes:
            try:
                await origin.edit("🚫 لغو شد؛ چیزی اجرا نشد.")
            except Exception:  # noqa: BLE001
                pass
            return True
        if pend["kind"] == "grant":
            await db.set_kv(GRANT_KEY, True)
            await run_request(origin, pend["request"], pend["reply_id"], pend.get("rinfo"))
        else:
            await execute(origin, pend["request"], pend["plan"], pend["reply_id"])
        return True

    @client.on(events.NewMessage(outgoing=True))
    async def confirm_watcher(event):
        """«بله» / «نه» written in the chat where the AI is waiting. Messages the AI itself sent are never taken as an answer."""
        if st["executing"] or not st["pending"]:
            return
        if (event.chat_id, getattr(event, "id", None)) in st["sent"]:
            return
        text = (event.raw_text or "").strip()
        if not text or len(text) > 40 or text.startswith(PREFIX):
            return
        yes, no = A.is_yes(text), A.is_no(text)
        if not (yes or no) or event.chat_id not in st["pending"]:
            return
        if await resolve(event, yes):
            try:
                await event.delete()  # the answer is not conversation: keep the chat clean
            except Exception:  # noqa: BLE001
                pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}ai\s+(yes|no)$"))
    async def ai_yes_no(event):
        if await resolve(event, event.pattern_match.group(1) == "yes"):
            try:
                await event.delete()
            except Exception:  # noqa: BLE001
                pass
            return
        await event.reply("ℹ️ الان چیزی در این گپ منتظر تأیید تو نیست.")

    # ------------------------------------------------------------------ .ai control
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}ai\s+control(?:\s+(on|off|status|log|danger))?(?:\s+(on|off))?$"))
    async def control_cmd(event):
        word, arg = (event.pattern_match.group(1) or "status"), event.pattern_match.group(2)
        if word == "on":
            await db.set_kv(GRANT_KEY, True)
            return await event.reply(f"🔓 کنترل اکانت برای AI روشن شد. با `{PREFIX}do درخواستت` استفاده کن؛ خاموش: `{PREFIX}ai control off`.")
        if word == "off":
            await db.set_kv(GRANT_KEY, False)
            st["pending"].clear()
            return await event.reply("🔒 کنترل اکانت برای AI خاموش شد. دفعهٔ بعد که `.do` بزنی دوباره اجازه می‌پرسه (یا `.ai control on`).")
        if word == "danger":
            if arg not in {"on", "off"}:
                return await event.reply(f"فرمت: `{PREFIX}ai control danger on|off`")
            await db.set_kv(DANGER_KEY, arg == "on")
            return await event.reply("🛡 دستورهای حساس " + ("قبل از اجرا «بله» می‌خوان." if arg == "on" else "بدون پرسیدن اجرا می‌شن (پیش‌فرض)."))
        if word == "log":
            entries = list(await db.get_kv(LOG_KEY, []) or [])[-10:]
            if not entries:
                return await event.reply("📜 هنوز AI کاری برای تو انجام نداده.")
            from datetime import datetime
            lines = []
            for e in reversed(entries):
                when = datetime.fromtimestamp(int(e.get("t", 0))).strftime("%m-%d %H:%M")
                lines.append(f"{when} «{e.get('req', '')[:50]}» → " + (" ; ".join(e.get("cmds", [])) or "—"))
            return await event.reply("📜 آخرین کارهای AI:\n" + "\n".join(lines)[:3800])
        on = await granted()
        return await event.reply(
            f"🤖 کنترل اکانت: {'روشن 🔓' if on else 'خاموش 🔒'} | دستورهای حساس: {'با تأیید' if await danger_on() else 'بدون تأیید'}\n"
            f"`{PREFIX}do درخواست` | `{PREFIX}ai control on|off` | `danger on|off` | `log`\n"
            f"همهٔ دستورها قابل اجرا هستن (فقط `{PREFIX}do` داخل `{PREFIX}do` نه).")
