"""Social downloader: YouTube, Instagram, TikTok  (powered by yt-dlp; the SERVER downloads, Telegram gets the file).

    .dl <link>                      interactive MP4 / MP3 picker (video by default if no Assistant Bot)
    .dl 360|480|720|1080|4k <link>  pick video quality        .dl best <link>  = 1080p
    .dl mp3 <link>                  audio-only MP3             .dl mp4 <link>  = video
    .dl <link>                      interactive MP4 / MP3 picker (Assistant Bot required)
    .dl me <link>                   send to Saved Messages instead of the chat
    .yt / .ig / .tt <link>          the same command (for habit)       Persian: «دانلود <لینک>»
    .dl status                      today's usage, yt-dlp / ffmpeg / cookies state

The server only borrows the file: it is deleted the moment it is uploaded (per album part, also when the upload fails),
and modules/storage_janitor.py sweeps anything a crash could leave behind.

.env:  DL_MAX_MB (default 300)  DL_MAX_MINUTES (60)  DL_DAILY_PER_ACCOUNT (25)  DL_DAILY_OWNER (200)  DL_CONCURRENCY (2)
       DL_MIN_FREE_MB (300: a download is refused while the server has less free disk)
       YTDLP_COOKIES=/path/cookies.txt (needed for private Instagram posts and for YouTube "confirm you're not a bot")  YTDLP_PROXY=
Only YouTube / Instagram / TikTok links are accepted (nothing else is ever handed to yt-dlp).
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import secrets
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from telethon import Button, events
from telethon.tl.types import DocumentAttributeAudio, DocumentAttributeVideo

from core.identity import owner_flag
from utils import dl as D
from utils import tmpclean
from utils.media_convert import FFMPEG, _run, probe

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ_NAME = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
DL_DIR = Path(__file__).resolve().parents[1] / "data" / "dl"
ALBUM_MAX = 10
MIN_FREE_MB_DEFAULT = 300
USAGE = (
    "⬇️ دانلودر یوتیوب / اینستاگرام / تیک‌تاک\n\n"
    f"`{PREFIX}dl لینک` — با Assistant Bot انتخاب کن: فیلم MP4 یا صدا MP3\n"
    f"`{PREFIX}dl mp4 لینک` — مستقیم ویدیو | `{PREFIX}dl mp3 لینک` — مستقیم فقط صدا\n"
    f"`{PREFIX}dl 480 لینک` | `{PREFIX}dl best لینک` (۱۰۸۰p)\n"
    f"`{PREFIX}dl me لینک` — به Saved Messages | `{PREFIX}dl info لینک` — فقط مشخصات\n"
    f"یا روی پیامی که لینک داره Reply کن و `{PREFIX}dl` بنویس. فارسی: «دانلود لینک».\n"
    f"`{PREFIX}dl status` — سهمیهٔ امروز و وضعیت"
)
_SEM = asyncio.Semaphore(max(1, int(os.getenv("DL_CONCURRENCY", "2") or 2)))
_PENDING: dict[str, dict[str, Any]] = {}
_PENDING_TTL = 15 * 60
_bot: Any = None
_fleet: Any = None
_ATTACHED_BOTS: set[int] = set()


def _picker_buttons(token: str):
    return [
        [Button.inline("🎬 فیلم (MP4)", f"dl:{token}:mp4".encode()), Button.inline("🎧 صدا / MP3", f"dl:{token}:mp3".encode())],
        [Button.inline("✖️ لغو", f"dl:{token}:cancel".encode())],
    ]


def _cleanup_pending() -> None:
    now = time.time()
    for token, request in list(_PENDING.items()):
        if now - float(request.get("created", 0)) > _PENDING_TTL:
            _PENDING.pop(token, None)


class _StatusEvent:
    """Small event-compatible wrapper used after a user picks a format from the Assistant Bot menu."""
    def __init__(self, message: Any, chat_id: int, reply_to_msg_id: int | None):
        self._message = message
        self.chat_id = chat_id
        self.reply_to_msg_id = reply_to_msg_id
        self.is_reply = reply_to_msg_id is not None

    async def edit(self, text: str, **kwargs):
        return await self._message.edit(text, **kwargs)

    async def delete(self):
        return await self._message.delete()


def _tz() -> ZoneInfo:
    try:
        return ZoneInfo(TZ_NAME)
    except Exception:  # noqa: BLE001
        return ZoneInfo("UTC")


def _int_env(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, "") or default))
    except ValueError:
        return default


def _find_url(m: Any) -> str | None:
    """A supported link inside a message: hidden link entities first, then plain text."""
    if m is None:
        return None
    for ent in getattr(m, "entities", None) or []:
        url = getattr(ent, "url", None)
        if url and D.platform_of(url):
            return url
    url = D.extract_url(getattr(m, "message", "") or "")
    return url if url and D.platform_of(url) else None


class _YdlLogger:
    """yt-dlp output -> the bot log. Warnings used to be thrown away (`no_warnings`), which hid the real cause of
    TikTok failures: "no impersonate target is available" (curl_cffi missing)."""

    def debug(self, msg: str) -> None:
        pass

    def info(self, msg: str) -> None:
        pass

    def warning(self, msg: str) -> None:
        log.info("yt-dlp warning: %s", re.sub(r"\x1b\[[0-9;]*m", "", str(msg))[:300])

    def error(self, msg: str) -> None:
        log.warning("yt-dlp error: %s", re.sub(r"\x1b\[[0-9;]*m", "", str(msg))[:300])


def _ydl_common(workdir: str, **kw) -> dict[str, Any]:
    opts = D.build_opts(workdir, max_mb=_int_env("DL_MAX_MB", 300), cookies=os.getenv("YTDLP_COOKIES", "").strip(),
                        proxy=os.getenv("YTDLP_PROXY", "").strip(), have_ffmpeg=bool(FFMPEG), **kw)
    opts["no_warnings"] = False  # the logger below keeps the console quiet but records the warnings
    opts["logger"] = _YdlLogger()
    return opts


def _extract(url: str, workdir: str) -> dict[str, Any]:
    import yt_dlp  # noqa: PLC0415 - imported late so the bot starts even if the package is missing

    opts = _ydl_common(workdir, audio=False, height=720)
    opts["skip_download"] = True
    with yt_dlp.YoutubeDL(opts) as ydl:
        return ydl.extract_info(url, download=False) or {}


def _fetch(url: str, workdir: str, audio: bool, height: int, hook: Any) -> None:
    import yt_dlp  # noqa: PLC0415

    with yt_dlp.YoutubeDL(_ydl_common(workdir, audio=audio, height=height, progress_hook=hook)) as ydl:
        ydl.download([url])


def _summary(info: dict[str, Any]) -> dict[str, Any]:
    """title / uploader / duration / count, also for carousels and playlists (first entry)."""
    entries = [e for e in (info.get("entries") or []) if e]
    first = entries[0] if entries else info
    return {
        "title": (info.get("title") or first.get("title") or "").strip(),
        "uploader": (info.get("uploader") or first.get("uploader") or first.get("channel") or "").strip(),
        "duration": info.get("duration") or first.get("duration") or 0,
        "live": bool(info.get("is_live") or first.get("is_live") or info.get("live_status") in {"is_live", "is_upcoming"}),
        "count": len(entries) or 1,
        "size": first.get("filesize") or first.get("filesize_approx") or 0,
    }


async def _thumb(src: str, dst: str) -> str | None:
    if not FFMPEG:
        return None
    for ss in ("1", "0"):
        code, _ = await _run(FFMPEG, "-y", "-loglevel", "error", "-ss", ss, "-i", src, "-frames:v", "1", "-vf", "scale=320:-2", dst, timeout=30)
        if code == 0 and Path(dst).exists():
            return dst
    return None


async def _execute_picked(request: dict[str, Any], mode: str) -> None:
    """Run a selected download using the original user account, not the Assistant Bot."""
    client = request["client"]
    try:
        status = await client.send_message(
            request["chat_id"],
            "⏳ آماده‌سازی دانلود " + ("ویدیو (MP4)…" if mode == "mp4" else "صدا (MP3)…"),
            reply_to=request.get("reply_to"),
        )
        event = _StatusEvent(status, request["chat_id"], request.get("reply_to"))
        opts = dict(request["opts"])
        opts["audio"] = mode == "mp3"
        opts["mode_explicit"] = True
        await request["runner"](event, opts, request["url"], request["platform"])
    except Exception as exc:  # noqa: BLE001
        log.warning("dl picked request failed (%s): %s", exc.__class__.__name__, str(exc)[:200])


def attach(bot, fleet=None) -> None:
    """Attach owner-checked format picker handlers to the shared Assistant Bot."""
    global _bot, _fleet
    _bot, _fleet = bot, fleet
    if id(bot) in _ATTACHED_BOTS:
        return
    _ATTACHED_BOTS.add(id(bot))

    async def on_inline(event):
        _cleanup_pending()
        token = event.pattern_match.group(1).decode() if isinstance(event.pattern_match.group(1), bytes) else event.pattern_match.group(1)
        request = _PENDING.get(token)
        if request is None or int(event.sender_id) != int(request["owner_id"]):
            return await event.answer([], cache_time=0, private=True)
        await event.answer([event.builder.article(
            "⬇️ انتخاب خروجی دانلود",
            text=("⬇️ <b>دانلودر هاپویی</b>\n\n"
                  f"لینک {D.NAMES[request['platform']]} آماده است.\n"
                  "خروجی دلخواه را انتخاب کن؛ فقط خودت می‌توانی این درخواست را کنترل کنی."),
            parse_mode="html", buttons=_picker_buttons(token),
            description="انتخاب فیلم MP4 یا صدا MP3"),], cache_time=0, private=True)

    async def on_callback(event):
        _cleanup_pending()
        try:
            _, token, mode = event.data.decode().split(":", 2)
        except (ValueError, UnicodeDecodeError):
            return await event.answer("دکمه نامعتبر است.", alert=True)
        request = _PENDING.get(token)
        if request is None:
            return await event.answer("این درخواست منقضی شده؛ دوباره لینک را بفرست.", alert=True)
        if int(event.sender_id) != int(request["owner_id"]):
            return await event.answer("فقط صاحب درخواست می‌تواند این دکمه‌ها را کنترل کند.", alert=True)
        if mode == "cancel":
            _PENDING.pop(token, None)
            await event.answer("درخواست لغو شد.")
            return await event.edit("✖️ درخواست دانلود لغو شد.", buttons=None)
        if mode not in {"mp3", "mp4"}:
            return await event.answer("نوع خروجی نامعتبر است.", alert=True)
        # Pop before scheduling, so rapid double clicks cannot start the same request twice.
        _PENDING.pop(token, None)
        await event.answer("درخواست ثبت شد؛ دانلود شروع می‌شود.")
        try:
            await event.edit("✅ انتخاب شد: " + ("🎬 فیلم MP4" if mode == "mp4" else "🎧 صدا MP3") + "\n⏳ وضعیت دانلود در پیام بعدی نمایش داده می‌شود.", buttons=None)
        except Exception:  # noqa: BLE001
            pass
        asyncio.create_task(_execute_picked(request, mode))

    bot.add_event_handler(on_inline, events.InlineQuery(pattern=r"^dl\s+([A-Za-z0-9_-]+)$"))
    bot.add_event_handler(on_callback, events.CallbackQuery(pattern=rb"^dl:.*"))


def setup(client, db):
    DL_DIR.mkdir(parents=True, exist_ok=True)
    if not D.impersonation_ok():
        log.warning("dl: browser impersonation is unavailable (curl_cffi missing/incompatible): TikTok downloads will fail. "
                    "Fix: pip install -U \"yt-dlp[default,curl-cffi]\"")
    state = {"busy": False}

    def cap() -> int:
        if owner_flag(client):
            return _int_env("DL_DAILY_OWNER", 200)
        return _int_env("DL_DAILY_PER_ACCOUNT", 25)

    def day_key() -> str:
        return "dl_used:" + datetime.now(_tz()).strftime("%Y-%m-%d")

    async def used() -> int:
        return int(await db.get_kv(day_key(), 0) or 0)

    async def add_used(delta: int) -> None:
        await db.set_kv(day_key(), max(0, await used() + delta))

    async def show_picker(event, opts: dict[str, Any], url: str, platform: str, runner) -> None:
        """Show an owner-only inline result; gracefully explain setup problems instead of losing the URL."""
        if _bot is None:
            # Preserve the old behaviour when this is configured as a standalone userbot without an Assistant Bot.
            direct = dict(opts)
            direct["audio"] = False
            return await runner(event, direct, url, platform)
        _cleanup_pending()
        token = secrets.token_urlsafe(8)
        try:
            owner = await client.get_me()
            owner_id = int(owner.id)
        except Exception:  # noqa: BLE001 - outgoing events usually carry sender_id; use it as a safe fallback
            owner_id = int(event.sender_id)
        _PENDING[token] = {
            "token": token, "created": time.time(), "owner_id": owner_id,
            "client": client, "runner": runner, "opts": dict(opts), "url": url, "platform": platform,
            "chat_id": int(event.chat_id), "reply_to": event.reply_to_msg_id if event.is_reply else None,
        }
        try:
            bot_user = await _bot.get_me()
            username = getattr(bot_user, "username", None)
            if not username:
                raise RuntimeError("Assistant Bot has no username")
            results = await client.inline_query(username, f"dl {token}")
            if results:
                await results[0].click(event.chat_id, reply_to=event.reply_to_msg_id if event.is_reply else None)
                try:
                    await event.delete()
                except Exception:  # noqa: BLE001
                    pass
                return
        except Exception as exc:  # noqa: BLE001
            log.info("dl inline picker fallback (%s: %s)", exc.__class__.__name__, str(exc)[:120])

        # Inline mode may be disabled; a direct bot message works where the bot is already allowed to post.
        try:
            await _bot.send_message(
                event.chat_id,
                "⬇️ <b>دانلودر هاپویی</b>\nنوع خروجی رو انتخاب کن. فقط صاحب درخواست می‌تونه دکمه‌ها رو اجرا کنه.",
                parse_mode="html", buttons=_picker_buttons(token),
                reply_to=event.reply_to_msg_id if event.is_reply else None,
            )
            try:
                await event.delete()
            except Exception:  # noqa: BLE001
                pass
            return
        except Exception as exc:  # noqa: BLE001
            _PENDING.pop(token, None)
            log.warning("dl picker unavailable (%s: %s)", exc.__class__.__name__, str(exc)[:160])
            return await event.reply(
                "❌ منوی انتخاب دانلود نمایش داده نشد. در @BotFather دستور /setinline را برای Assistant Bot فعال کن "
                "یا بات را به گپ اضافه کن. فعلاً مستقیم بزن: "
                f"`{PREFIX}dl mp4 لینک` یا `{PREFIX}dl mp3 لینک`."
            )

    async def send_result(event, files: list[Path], caption: str, opts: dict[str, Any], summ: dict[str, Any]) -> int:
        target = "me" if opts["me"] else event.chat_id
        reply_to = event.reply_to_msg_id if (event.is_reply and not opts["me"]) else None
        last_edit = [0.0]

        async def progress(done, total):
            now = time.monotonic()
            if total and now - last_edit[0] > 4:
                last_edit[0] = now
                try:
                    await event.edit(f"⬆️ آپلود… {int(done * 100 / total)}٪")
                except Exception:  # noqa: BLE001
                    pass

        sent = 0
        if len(files) > 1:
            for i in range(0, len(files), ALBUM_MAX):
                chunk = [str(p) for p in files[i:i + ALBUM_MAX]]
                await client.send_file(target, chunk, caption=[caption] + [""] * (len(chunk) - 1) if i == 0 else None,
                                       reply_to=reply_to, progress_callback=progress)
                sent += len(chunk)
                tmpclean.purge(*chunk)  # already in Telegram: free the disk before the next part is uploaded
            return sent
        path = files[0]
        kind = D.kind_of(path)
        kwargs: dict[str, Any] = {"caption": caption, "reply_to": reply_to, "progress_callback": progress}
        thumb = None
        if kind == "video":
            meta = await probe(str(path))
            attrs = [DocumentAttributeVideo(duration=int(meta.get("duration") or summ["duration"] or 0), w=int(meta.get("w") or 0),
                                            h=int(meta.get("h") or 0), supports_streaming=True)]
            thumb = await _thumb(str(path), str(path.with_suffix(".thumb.jpg")))
            kwargs.update(attributes=attrs, supports_streaming=True, force_document=False)
            if thumb:
                kwargs["thumb"] = thumb
        elif kind == "audio":
            kwargs.update(attributes=[DocumentAttributeAudio(duration=int(summ["duration"] or 0), title=(summ["title"] or path.stem)[:60],
                                                              performer=(summ["uploader"] or "")[:60])], force_document=False)
        elif kind == "image":
            kwargs["force_document"] = False
        try:
            await client.send_file(target, str(path), **kwargs)
        finally:
            tmpclean.purge(str(path), thumb)  # uploaded (or failed): the server copy is of no use any more
        return 1

    async def run(event, opts: dict[str, Any], url: str, platform: str) -> None:
        if state["busy"]:
            return await event.edit("⏳ یک دانلود دیگه در حال انجامه؛ تموم که شد دوباره بفرست.")
        n = await used()
        if n >= cap() and not opts["info"]:
            return await event.edit(f"⏳ سهمیهٔ دانلود امروز تموم شد ({n}/{cap()}). نیمه‌شب دوباره پر می‌شه.")
        min_free = _int_env("DL_MIN_FREE_MB", MIN_FREE_MB_DEFAULT)
        if not opts["info"] and tmpclean.free_mb(DL_DIR) < min_free:
            await asyncio.to_thread(tmpclean.sweep_all, 0)  # drop every idle leftover, then look again
            if tmpclean.free_mb(DL_DIR) < min_free:
                return await event.edit(f"❌ فضای خالی سرور کمه (کمتر از {min_free} MB)؛ بعداً امتحان کن یا `{PREFIX}storage` رو ببین.")
        state["busy"] = True
        workdir = tmpclean.new_workdir(DL_DIR, "dl_")
        counted = False
        ticker = None
        try:
            await event.edit(f"🔎 بررسی لینک {D.NAMES[platform]}…")
            try:
                info = await asyncio.wait_for(asyncio.to_thread(_extract, url, workdir), 90)
            except ImportError:
                return await event.edit("❌ بسته yt-dlp نصب نیست: `pip install -U yt-dlp` و ربات را ری‌استارت کن.")
            summ = _summary(info)
            if opts["info"]:
                size = f"\n📦 حدود {D.human_size(summ['size'])}" if summ["size"] else ""
                return await event.edit(f"ℹ️ {D.NAMES[platform]}\n🎬 {summ['title'][:150] or '—'}\n👤 {summ['uploader'] or '—'}\n"
                                        f"⏱ {D.human_duration(summ['duration'])}\n🧩 {summ['count']} فایل{size}")
            if summ["live"]:
                return await event.edit("❌ لایو یا ویدیوی هنوز-شروع‌نشده قابل دانلود نیست.")
            max_min = _int_env("DL_MAX_MINUTES", 60)
            if summ["duration"] and summ["duration"] > max_min * 60:
                return await event.edit(f"❌ ویدیو {D.human_duration(summ['duration'])} است؛ سقف مجاز {max_min} دقیقه (DL_MAX_MINUTES). "
                                        f"می‌تونی `{PREFIX}dl audio` امتحان کنی.")
            await add_used(1)
            counted = True
            prog: dict[str, Any] = {}

            def hook(d):  # runs in the download thread; only stores numbers
                if d.get("status") == "downloading":
                    prog["done"] = d.get("downloaded_bytes") or 0
                    prog["total"] = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                elif d.get("status") == "finished":
                    prog["finished"] = True

            async def tick():
                while True:
                    await asyncio.sleep(4)
                    if prog.get("total"):
                        text = f"⏳ دانلود روی سرور… {int(prog['done'] * 100 / prog['total'])}٪ ({D.human_size(prog['done'])}/{D.human_size(prog['total'])})"
                    elif prog.get("finished"):
                        text = "⚙️ در حال پردازش فایل…"
                    else:
                        text = "⏳ دانلود روی سرور…"
                    try:
                        await event.edit(text)
                    except Exception:  # noqa: BLE001
                        pass

            await event.edit("⏳ دانلود روی سرور…")
            ticker = asyncio.create_task(tick())
            async with _SEM:
                await asyncio.wait_for(asyncio.to_thread(_fetch, url, workdir, opts["audio"], opts["height"], hook), 20 * 60)
            ticker.cancel()
            ticker = None
            files = D.collect_files(workdir)
            if opts["audio"]:
                audio_files = [f for f in files if D.kind_of(f) == "audio"]
                files = audio_files or files
            if not files:
                await add_used(-1)
                counted = False
                return await event.edit(D.friendly_error("File is larger than max-filesize" if summ["size"] and summ["size"] > _int_env("DL_MAX_MB", 300) * 1048576
                                                         else "هیچ فایلی دریافت نشد", platform))
            biggest = max(f.stat().st_size for f in files)
            if biggest > 1950 * 1024 * 1024:
                return await event.edit("❌ فایل از حد تلگرام (۲ گیگابایت) بزرگ‌تره؛ کیفیت پایین‌تر بده.")
            caption = f"🎬 {summ['title'][:200]}" if summ["title"] else ""
            if summ["uploader"]:
                caption += f"\n👤 {summ['uploader'][:80]}"
            caption = (caption.strip() or D.NAMES[platform])[:900]
            await event.edit("⬆️ آپلود به تلگرام…")
            sent = await send_result(event, files, caption, opts, summ)
            tmpclean.release(workdir)  # everything is in Telegram now: the server keeps nothing
            try:
                if opts["me"]:
                    await event.edit(f"✅ {sent} فایل در Saved Messages ذخیره شد.")
                    await asyncio.sleep(3)
                await event.delete()
            except Exception:  # noqa: BLE001
                pass
        except asyncio.TimeoutError:
            if counted:
                await add_used(-1)
            await event.edit("❌ زمان دانلود خیلی طول کشید و قطع شد. دوباره امتحان کن یا کیفیت را پایین‌تر بده.")
        except Exception as exc:  # noqa: BLE001
            if counted:
                await add_used(-1)
            log.warning("dl failed (%s): %s", platform, str(exc)[:300])
            try:
                await event.edit("❌ " + D.friendly_error(str(exc), platform))
            except Exception:  # noqa: BLE001
                pass
        finally:
            if ticker is not None:
                ticker.cancel()
            state["busy"] = False
            tmpclean.release(workdir)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?is)^(?:{P}(?:dl|ytdl|yt|ig|tt)|دانلود)(?:\s+(.*))?$"))
    async def dl_cmd(event):
        raw = (event.pattern_match.group(1) or "").strip()
        persian = not (event.raw_text or "").lstrip().startswith(PREFIX)
        if raw.lower() == "status" and not persian:
            n = await used()
            try:
                import yt_dlp  # noqa: PLC0415
                ver = getattr(getattr(yt_dlp, "version", None), "__version__", "?")
            except ImportError:
                ver = "نصب نیست ❌ (pip install -U yt-dlp)"
            cookies = os.getenv("YTDLP_COOKIES", "").strip()
            imp = "✅" if D.impersonation_ok() else "❌ (pip install -U yt-dlp[default,curl-cffi])"
            return await event.reply(f"⬇️ دانلودر\nامروز: {n}/{cap()}\nyt-dlp: {ver}\nffmpeg: {'✅' if FFMPEG else '❌ (apt install ffmpeg)'}\n"
                                     f"curl_cffi (برای تیک‌تاک): {imp}\n"
                                     f"فضای خالی سرور: {tmpclean.free_mb(DL_DIR):.0f} MB\n"
                                     f"کوکی: {'✅' if cookies and Path(cookies).is_file() else '—'}\n"
                                     f"سقف: {_int_env('DL_MAX_MB', 300)}MB / {_int_env('DL_MAX_MINUTES', 60)} دقیقه")
        opts = D.parse_args(raw)
        url = opts["url"]
        if not url and event.is_reply:
            url = _find_url(await event.get_reply_message())
        if not url:
            if persian:
                return  # normal chatting that happens to start with «دانلود»
            return await event.reply(USAGE)
        platform = D.platform_of(url)
        if not platform:
            if persian:
                return
            return await event.reply("❌ فقط لینک YouTube / Instagram / TikTok پشتیبانی می‌شه.")
        if not opts["info"] and not opts["mode_explicit"] and not opts["quality_explicit"]:
            return await show_picker(event, opts, url, platform, run)
        await run(event, opts, url, platform)
