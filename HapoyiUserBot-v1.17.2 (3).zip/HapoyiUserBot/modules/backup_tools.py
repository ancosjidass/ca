"""Automatic backups + restore.

    .autobackup on|off|status|now      a database snapshot goes to your Saved Messages every 24 h (default OFF)
    .restore                           Reply to a backup file (the .db you got) -> checks it and asks for confirmation
    .restore confirm                   within 2 minutes: put the backup's data back (tables that are newer than the
                                       backup stay as they are; licenses / accounts are never touched)
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import sqlite3
import tempfile
import time
from datetime import datetime

from telethon import events

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
INTERVAL = float(os.getenv("AUTOBACKUP_HOURS", "24") or 24) * 3600
CONFIRM_TTL = 120
MAX_SIZE = 200 * 1024 * 1024


def validate_backup(path: str) -> str | None:
    """None when `path` is a healthy Hāpoyi database, else the reason it is not."""
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                return "فایل خراب است (integrity_check)."
            names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            con.close()
    except sqlite3.DatabaseError:
        return "این فایل دیتابیس SQLite نیست."
    return None if "kv" in names else "این فایل بکاپ Hāpoyi نیست."


def setup(client, db):
    pending: dict[str, object] = {}

    async def send_backup(caption: str) -> None:
        fd, path = tempfile.mkstemp(suffix=".db", prefix="hapoyi_auto_")
        os.close(fd)
        try:
            await db.backup_to(path)
            await client.send_file("me", path, caption=caption, file_name=f"hapoyi_backup_{datetime.now().strftime('%Y%m%d_%H%M')}.db")
            await db.set_kv("autobackup_last", time.time())
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass

    async def loop() -> None:
        while True:
            try:
                await asyncio.sleep(1800)
                if await db.get_kv("autobackup_on", False) and time.time() - float(await db.get_kv("autobackup_last", 0) or 0) >= INTERVAL:
                    await send_backup("💾 بکاپ خودکار Hāpoyi")
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("autobackup: %s: %s", exc.__class__.__name__, exc)

    asyncio.get_running_loop().create_task(loop())

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}autobackup(?:\s+(on|off|status|now))?$"))
    async def autobackup(event):
        word = event.pattern_match.group(1) or "status"
        if word in {"on", "off"}:
            await db.set_kv("autobackup_on", word == "on")
            return await event.reply("💾 بکاپ خودکار " + ("روشن شد؛ هر ۲۴ ساعت یک فایل به Saved Messages می‌آید." if word == "on" else "خاموش شد."))
        if word == "now":
            await send_backup("💾 بکاپ دستی Hāpoyi")
            return await event.reply("💾 بکاپ در Saved Messages ذخیره شد.")
        last = float(await db.get_kv("autobackup_last", 0) or 0)
        await event.reply(f"💾 بکاپ خودکار: {'ON' if await db.get_kv('autobackup_on', False) else 'OFF'}\n"
                          f"آخرین بکاپ: {datetime.fromtimestamp(last).strftime('%Y-%m-%d %H:%M') if last else '—'}\n"
                          f"`{PREFIX}autobackup on|off|now` | `{PREFIX}restore` (Reply روی فایل بکاپ)")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}restore(?:\s+(confirm))?$"))
    async def restore(event):
        if event.pattern_match.group(1):
            path, ts = pending.get("path"), float(pending.get("ts", 0))  # type: ignore[arg-type]
            if not path or time.time() - ts > CONFIRM_TTL or not os.path.exists(str(path)):
                return await event.reply(f"ℹ️ چیزی برای تأیید نیست؛ دوباره `{PREFIX}restore` را روی فایل بکاپ Reply کن.")
            try:
                tables, rows = await db.restore_from(str(path))
            except Exception as exc:  # noqa: BLE001
                return await event.reply(f"❌ بازگردانی انجام نشد و هیچ تغییری اعمال نشد ({exc.__class__.__name__}).")
            finally:
                try:
                    os.unlink(str(path))
                except OSError:
                    pass
                pending.clear()
            return await event.reply(f"✅ بازگردانی شد: {tables} جدول، {rows} ردیف.\n(برای اعمال کامل بهتر است سلف را یک بار ری‌استارت کنی.)")
        m = await event.get_reply_message() if event.is_reply else None
        if m is None or not getattr(m, "document", None):
            return await event.reply("❌ روی فایل بکاپ (.db) Reply کن.")
        if getattr(m.file, "size", 0) > MAX_SIZE:
            return await event.reply("❌ فایل خیلی بزرگ است.")
        fd, path = tempfile.mkstemp(suffix=".db", prefix="hapoyi_restore_")
        os.close(fd)
        await client.download_media(m, file=path)
        problem = validate_backup(path)
        if problem:
            os.unlink(path)
            return await event.reply("❌ " + problem)
        pending.update(path=path, ts=time.time())
        await event.reply(f"⚠️ فایل سالم است. داده‌های فعلی این اکانت با آن جایگزین می‌شود.\nبرای تأیید تا ۲ دقیقه: `{PREFIX}restore confirm`")
