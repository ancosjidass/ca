from __future__ import annotations

import asyncio
import os
import time
from pathlib import Path

from telethon import events
from telethon.tl.types import DocumentAttributeAnimated, DocumentAttributeVideo, MessageMediaWebPage
from PIL import Image, ImageEnhance, ImageOps

from utils import tmpclean
from utils.media_convert import ConvertError, image_to_gif_mp4, video_to_gif_mp4

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
MEDIA_DIR = Path(__file__).resolve().parents[1] / "data" / "media"
MEDIA_DIR.mkdir(parents=True, exist_ok=True)


def _cleanup(*paths) -> None:
    for p in paths:
        try:
            if p:
                os.remove(p)
        except OSError:
            pass


def setup(client, db):
    # ------------------------------------------------------------------ download -> Saved Messages
    # `.download` or just `دانلود` as a reply, in ANY chat / PV / group / channel comments:
    # the SERVER downloads the media and re-uploads it to your Saved Messages, so a weak phone
    # connection does not matter (you can close the app; the file shows up in Saved Messages).
    async def _album_of(m) -> list:
        gid = getattr(m, "grouped_id", None)
        if not gid:
            return [m]
        try:
            near = await client.get_messages(m.chat_id, ids=list(range(max(1, m.id - 10), m.id + 11)))
            group = [x for x in near if x is not None and getattr(x, "grouped_id", None) == gid and x.media]
            return sorted(group, key=lambda x: x.id) or [m]
        except Exception:  # noqa: BLE001
            return [m]

    def _src_caption(chat, sender, m) -> str:
        chat_name = getattr(chat, "title", None) or " ".join(x for x in (getattr(chat, "first_name", None), getattr(chat, "last_name", None)) if x) or "PV"
        who = " ".join(x for x in (getattr(sender, "first_name", None), getattr(sender, "last_name", None)) if x) or getattr(sender, "title", None) or getattr(sender, "username", None) or ""
        text = (getattr(m, "message", "") or "").strip()
        head = f"📥 {chat_name}" + (f" • {who}" if who and who != chat_name else "")
        return (head + ("\n" + text if text else ""))[:1000]

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?i)^(?:{__import__('re').escape(PREFIX)}download|دانلود|دانلود\s+کن)$"))
    async def download(event):
        explicit = (event.raw_text or "").strip().startswith(PREFIX)
        if not event.is_reply:
            if explicit:
                await event.reply("❌ روی یک مدیا Reply کن و بنویس `.download` یا `دانلود`.")
            return  # the bare word "دانلود" in normal chatting is left alone
        m = await event.get_reply_message()
        if m is not None and not getattr(m, "document", None) and isinstance(getattr(m, "media", None), MessageMediaWebPage):
            # a YouTube / Instagram / TikTok link: `modules/downloader.py` handles it (`.dl`); here only the preview picture would be saved
            from utils.dl import extract_url, platform_of  # noqa: PLC0415
            link = extract_url(getattr(m, "message", "") or "")
            if link and platform_of(link):
                if explicit:
                    await event.reply(f"ℹ️ این یک لینک شبکهٔ اجتماعیه؛ با `{PREFIX}dl` (Reply روی همین پیام) ویدیو/موزیک رو دانلود کن.")
                return
        if m is None or not (m.photo or m.document):
            if explicit:
                await event.reply("❌ این پیام مدیا ندارد.")
            return
        workdir = tmpclean.new_workdir(MEDIA_DIR, "dlm_")
        sent = 0
        try:
            chat = await event.get_chat()
            items = await _album_of(m)
            last_edit = [0.0]

            async def progress(done, total):
                now = time.monotonic()
                if total and now - last_edit[0] > 4:
                    last_edit[0] = now
                    try:
                        await event.edit(f"⏳ دانلود روی سرور… {int(done * 100 / total)}٪")
                    except Exception:  # noqa: BLE001
                        pass

            try:
                await event.edit("⏳ دانلود روی سرور…")
            except Exception:  # noqa: BLE001
                pass
            for idx, item in enumerate(items):
                path = await client.download_media(item, file=workdir + "/", progress_callback=progress)
                if not path:
                    continue
                sender = None
                try:
                    sender = await item.get_sender()
                except Exception:  # noqa: BLE001
                    pass
                doc = getattr(item, "document", None)
                kwargs = {}
                if doc is not None:
                    kwargs = {"attributes": doc.attributes, "mime_type": doc.mime_type, "force_document": False}
                    if getattr(item, "voice", None):
                        kwargs["voice_note"] = True
                try:
                    await client.send_file("me", path, caption=_src_caption(chat, sender, item) if idx == 0 else None, **kwargs)
                finally:
                    _cleanup(path)  # in Saved Messages (or failed): the server copy is deleted right away
                sent += 1
            if sent:
                try:
                    await event.edit(f"✅ {sent} فایل در Saved Messages ذخیره شد.")
                    await asyncio.sleep(2)
                    await event.delete()
                except Exception:  # noqa: BLE001
                    pass
            else:
                await event.edit("❌ دانلود نشد.")
        finally:
            tmpclean.release(workdir)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}rename\s+(.+)$"))
    async def rename(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی فایل.")
        m = await event.get_reply_message()
        wanted = os.path.basename(event.pattern_match.group(1).strip().replace("\\", "/"))  # a name only, never a path
        if not wanted or wanted in {".", ".."}:
            return await event.reply("❌ اسم فایل نامعتبر است.")
        workdir = tmpclean.new_workdir(MEDIA_DIR, "ren_")
        try:
            path = await m.download_media(file=workdir + "/")
            if not path:
                return await event.reply("❌ دانلود نشد.")
            new = Path(workdir) / wanted
            Path(path).replace(new)
            await client.send_file(event.chat_id, str(new))
        finally:
            tmpclean.release(workdir)

    def _is_video(m) -> bool:
        doc = getattr(m, "document", None)
        mime = (getattr(doc, "mime_type", "") or "").lower()
        return bool(getattr(m, "video", None) or getattr(m, "video_note", None) or getattr(m, "gif", None) or mime.startswith("video/"))

    def _is_image(m) -> bool:
        doc = getattr(m, "document", None)
        mime = (getattr(doc, "mime_type", "") or "").lower()
        return bool(getattr(m, "photo", None) or mime in {"image/jpeg", "image/png", "image/webp", "image/bmp"})

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}sticker$"))
    async def sticker(event):
        if not event.is_reply:
            return await event.reply("❌ روی یک عکس Reply کن.")
        m = await event.get_reply_message()
        if not _is_image(m):
            return await event.reply("❌ فقط روی عکس Reply کن (برای ویدیو از `.gif` استفاده کن).")
        workdir = tmpclean.new_workdir(MEDIA_DIR, "stk_")
        try:
            path = await m.download_media(file=workdir + "/")
            if not path:
                return await event.reply("❌ دانلود نشد.")
            try:
                with Image.open(path) as src:
                    im = src.convert("RGBA")
                im.thumbnail((512, 512), Image.Resampling.LANCZOS)
                out = str(Path(path).with_suffix(".webp"))
                im.save(out, "WEBP", lossless=True, quality=90)
                await client.send_file(event.chat_id, out, force_document=False, reply_to=event.reply_to_msg_id)
                await event.delete()
            except Exception as exc:  # noqa: BLE001
                await event.reply(f"❌ تبدیل نشد: {exc}")
        finally:
            tmpclean.release(workdir)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}gif$"))
    async def gif(event):
        """Reply to a photo -> 3s looping zoom GIF; reply to a video / video-note / video-sticker -> real GIF."""
        if not event.is_reply:
            return await event.reply("❌ روی عکس یا ویدیو Reply کن.")
        m = await event.get_reply_message()
        doc = getattr(m, "document", None)
        if doc and (getattr(doc, "mime_type", "") or "") == "application/x-tgsticker":
            return await event.reply("❌ استیکرهای انیمیشنی (tgs) پشتیبانی نمی‌شوند؛ روی عکس/ویدیو/استیکر ویدیویی Reply کن.")
        is_video, is_image = _is_video(m), _is_image(m)
        if not (is_video or is_image):
            return await event.reply("❌ روی عکس یا ویدیو Reply کن.")
        workdir = tmpclean.new_workdir(MEDIA_DIR, "gif_")
        src = out = None
        try:
            src = await m.download_media(file=workdir + "/")
            if not src:
                return await event.reply("❌ دانلود نشد.")
            out = str(Path(workdir) / "result.mp4")
            info = await (video_to_gif_mp4(src, out) if is_video else image_to_gif_mp4(src, out))
            attrs = [DocumentAttributeAnimated()]
            if info.get("w") and info.get("h"):
                attrs.append(DocumentAttributeVideo(duration=int(info.get("duration") or 1), w=int(info["w"]), h=int(info["h"]), supports_streaming=True))
            await client.send_file(event.chat_id, out, attributes=attrs, mime_type="video/mp4", force_document=False, reply_to=event.reply_to_msg_id)
            await event.delete()
        except ConvertError as exc:
            await event.reply(f"❌ {exc}")
        except Exception as exc:  # noqa: BLE001
            await event.reply(f"❌ GIF ساخته نشد: {exc.__class__.__name__}")
        finally:
            tmpclean.release(workdir)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}resize\s+(\d+)\s+(\d+)$"))
    async def resize(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس.")
        m = await event.get_reply_message()
        w, h = int(event.pattern_match.group(1)), int(event.pattern_match.group(2))
        if w * h > 20_000_000:
            return await event.reply("❌ اندازه خیلی بزرگ است.")
        workdir = tmpclean.new_workdir(MEDIA_DIR, "rsz_")
        try:
            path = await m.download_media(file=workdir + "/")
            if not path:
                return await event.reply("❌ دانلود نشد.")
            try:
                with Image.open(path) as src:
                    im = src.convert("RGB").resize((w, h), Image.Resampling.LANCZOS)
                out = str(Path(workdir) / "resized.jpg")
                im.save(out, quality=90)
                await client.send_file(event.chat_id, out)
            except Exception as exc:  # noqa: BLE001
                await event.reply(f"❌ تغییر اندازه نشد: {exc.__class__.__name__}")
        finally:
            tmpclean.release(workdir)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{__import__('re').escape(PREFIX)}watermark\s+(.+)$"))
    async def watermark(event):
        if not event.is_reply:
            return await event.reply("❌ Reply روی عکس.")
        m = await event.get_reply_message()
        workdir = tmpclean.new_workdir(MEDIA_DIR, "wm_")
        try:
            path = await m.download_media(file=workdir + "/")
            if not path:
                return await event.reply("❌ دانلود نشد.")
            try:
                from PIL import ImageDraw
                with Image.open(path) as src:
                    im = src.convert("RGBA")
                draw = ImageDraw.Draw(im)
                text = event.pattern_match.group(1)
                draw.text((20, im.height - 50), text, fill=(255, 255, 255, 180), stroke_width=2, stroke_fill=(0, 0, 0, 180))
                out = str(Path(workdir) / "watermarked.png")
                im.save(out)
                await client.send_file(event.chat_id, out)
            except Exception as exc:  # noqa: BLE001
                await event.reply(f"❌ Watermark failed: {exc}")
        finally:
            tmpclean.release(workdir)
