from __future__ import annotations

import os
import re
from pathlib import Path

from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
BASE = Path(__file__).resolve().parents[1]
HELP_FILE = BASE / "docs" / "HELP.txt"

SECTIONS = {
    "admin": """🛡️ Admin\n{p}ban [user]\n{p}unban [user]\n{p}kick [user]\n{p}mute [user] [duration]\n{p}unmute [user]\n{p}warn [user] [reason]\n{p}warnings [user]\n{p}unwarn [user]\n{p}del (reply)\n{p}delmes <count> | {p}purge <count> (آخرین N پیام گروه را پاک می‌کند؛ ادمین با حق Delete؛ تا ۱۰۰۰؛ با Reply از آن پیام تا آخر)\n{p}pin / {p}unpin\n{p}promote [user]  (Pin+Delete+Invite+Ban)\n{p}demote [user]\n{p}banned users\n{p}mute users\n{p}admins""",
    "security": """🔐 Security\n{p}autoban on|off [ban|mute|delete]\n{p}whitelist add|del|list [user]\n{p}autodelete enable|disable|list [user]\n{p}filter scope normal|all\n{p}filter add|del|list <text>\n{p}flood on|off <count> <seconds>\n{p}safety on|off|status\n{p}floodguard on|off|status""",
    "chat": """👥 Chat Guard\n{p}welcome on|off [template]\n{p}leave on|off\n{p}linkguard on|off [all|invite] [delete|warn|mute|ban] [duration]
{p}linkguard scope normal|all
{p}linkguard threshold <count> <window> <action> [duration]\n{p}rate <count> <window>\n{p}rate off""",
    "personal": """🧠 Personal\n{p}afk [reason]\n{p}back\n{p}note add|get|del|list\n{p}remind <duration> <text>\n{p}clock\n{p}profileclock on|off|status  (بیو + اسم)\n{p}profileclock name on|off  (Last name = ساعت)\n{p}profileclock bio on|off\n{p}profileclock digits fa|en\n{p}clone [user]  (Reply یا @user/ID)\n{p}unclone\n{p}bio <text>\n{p}stats\n{p}userinfo [user]\n{p}chatinfo\n{p}time <zone>""",
    "relations": """🤝 Friends / Enemies\n{p}friend add|del|on|off|list [user]\n{p}enemy add|del|on|off|list [user]\n{p}friend reply <text>\n{p}enemy reply <text>\n{p}relation reply friend|enemy <text>\n{p}relation replies [friend|enemy]\n{p}relation stats\n{p}relation cooldown friend|enemy <seconds>\n{p}relation clear [friend|enemy]  (کاملاً خالی)\n{p}relation reset [friend|enemy]  (برگشت پیش‌فرض)\nبرای target می‌توانی username/ID بدهی یا روی پیامش Reply کنی. پاسخ‌ها تصادفی‌اند و cooldown دارند.""",
    "crypto": """💰 Market\nدلار / یورو / بیت کوین / تتر / سولانا\n{p}price <symbol>  (دلار/یورو/کریپتو، لحظه‌ای)\n{p}pricesrc  (وضعیت منابع قیمت)\n{p}market\n{p}alert <usd|eur|btc...> >|< <price>\n{p}alerts\n{p}alertdel <id>\n{p}hold add|set|del <coin> <qty>\n{p}portfolio""",
    "tools": """🧰 Tools\n{p}calc <expression>\n{p}msginfo (reply)\n{p}id [user/chat]\n{p}save (reply)\n{p}search <text>\n{p}readall\n{p}react <emoji> (reply)\n{p}rawchat""",
    "media": """🎞️ Media\n{p}download | دانلود  (Reply روی مدیا، در هر چتی؛ سرور دانلود می‌کنه و به Saved Messages می‌فرسته)\n{p}ss | اسکرین  (Reply روی پیام → استیکر اسکرین‌شاتی؛ {p}ss light | {p}ss quote)\n{p}sticker  (Reply روی عکس)\n{p}gif  (Reply روی عکس/ویدیو) (reply photo)\n{p}rename <name> (reply file)\n{p}resize <width> <height> (reply photo)\n{p}watermark <text> (reply photo)""",
    "dl": """⬇️ دانلودر (YouTube / Instagram / TikTok)\n{p}dl <لینک>  (منوی شیشه‌ای انتخاب خروجی: 🎬 MP4 یا 🎧 MP3؛ یا Reply روی پیامی که لینک داره)\n{p}dl mp4 <لینک>  (مستقیم ویدیو) | {p}dl mp3 <لینک>  (مستقیم فقط صدا)\n{p}dl 360|480|720|1080|4k <لینک> | {p}dl best <لینک>\n{p}dl me <لینک>  (به Saved Messages)\n{p}dl info <لینک>  (عنوان، مدت، حجم؛ بدون دانلود)\n{p}yt | {p}ig | {p}tt <لینک>  (همان دستور)  |  فارسی: دانلود <لینک>\n{p}dl status  (سهمیهٔ امروز، yt-dlp، ffmpeg، کوکی)\nمنوی تعاملی به Assistant Bot نیاز داره: BOT_TOKEN را تنظیم کن و در @BotFather دستور /setinline را فعال کن. دکمه‌های انتخاب فقط برای صاحب همان درخواست کار می‌کنند. سرور دانلود می‌کنه و فایل رو برای تو می‌فرسته؛ پست‌های خصوصی اینستاگرام و بعضی ویدیوهای یوتیوب به کوکی نیاز دارن.""",
    "message": """🧹 Message Tools\n{p}delafter <duration> (reply)\n{p}selfdestruct <duration> <text>\n{p}selfdestruct list | del <id|all> | now <id|all>\n{p}mesdel all | <n>  (پیام‌های خودت در این گپ)\n{p}mesdel all | <n> <chat id یا @username>  (بدون رفتن به گپ)\n{p}reactdel <n|all> [chat id یا @username]  (ری‌اکشن‌های خودت را از n پیام آخر برمی‌دارد؛ بدون گپ = همین گپ)\n{p}cleanme [count]""",
    "games": """🎲 Games\n{p}casino <target>  (با Reply: روی همان پیام ریپلای می‌شود)\n{p}casino smart 777 [max_rolls]\n{p}casino hooshmad 777 [max_rolls]\n{p}dice|dart|bowling|basket|football <target>\n{p}game cancel\n{p}game status\n{p}coin\n{p}xo  (دوز دو نفره با دکمه؛ آمار در دیتابیس خودت)\n{p}menu  (منو در هر چتی با Inline؛ یا @بات را در چت تایپ کن)\n{p}rps rock|paper|scissors  (تک‌نفره با بات)\n{p}rps [1|3|5..9]  (دو نفره با دکمه‌های مخفی؛ در پیوی حریف خودکار، در گروه Reply یا اولین نفر)""",
    "automation": """⏰ Automation\n{p}autoreply add|del|list|on|off\n{p}watch add|del|list\n{p}autoreact <emoji> (Reply = فقط همان کاربر، بدون Reply = کل گپ)\n{p}autoreact off|on|del [user|all] / list / clear\n{p}notify add|del|list <chat> <keyword>\n{p}jobs\n{p}jobdel <id>""",
    "power": """⚡ ابزارهای قدرتی\\n{p}every 5m <متن>  یا  {p}time <متن> 5m  (تکرار نامحدود؛ بازه ۱ثانیه تا ۷۲ساعت)\\n{p}every 10m 5 <متن>  یا  x5  (حداکثر ۵ پیام، بعدش عملیات پاک می‌شه)\\n{p}every 10m - <متن>  (- = نامحدود)\\n{p}every list [all] | pause|resume <id|all> | del <id|all|allchats>\\n{p}tag [N] | {p}tag admin [N] | {p}tag normal [N] | {p}tag stop  (حداکثر ۳۰۰)\\n{p}later 10m <متن>  (ارسال زمان‌بندی‌شده توسط تلگرام)  | later list | later del <id|all>\\n{p}top [N]  (فعال‌ترین‌ها)\\n{p}export [N]  (پیام‌های گپ → Saved Messages)\\n{p}slowmode off|10s|30s|1m|5m|15m|1h\\n{p}lock [all|media|stickers|gifs|links|polls|invite|pin|info] | {p}unlock ... | {p}lock status\\n{p}delall [@user] [N]  (پیام‌های یک نفر)\\n{p}poll [multi] [public] سؤال | گزینه | گزینه\\n{p}qr <متن>\\n{p}pass [طول]\\n{p}link [new]""",
    "account": """🔐 اکانت، لایسنس و محافظ\n{p}report on|off|status|where bio|name — پروفایل: ONLINE وقتی سلف روشن است، OFFLINE وقتی خاموش شد (هر اکانت جدا)\n{p}whoami — اکانت فعلی و اعتبار لایسنس\n{p}deactivate — (اکانت‌های لایسنس‌دار) خاموش‌کردن سلف روی همین اکانت؛ با دکمهٔ «فعال‌کردن» در بات کنترل برمی‌گردد\n{p}protect on | off | status — Account Protect: هر لاگین جدیدی که در زمان روشن‌بودن بسازد فوراً بسته می‌شود؛ سشن‌های قبلی و سشن‌های زمان خاموشی دست نمی‌خورند\n\nفقط اکانت اصلی (مالک):\n{p}lic new <30s|12h|3d|1m> [نام] — ساخت لایسنس (کد در Saved Messages)\n{p}lic list | off <id> | on <id> | del <id>\n\nبات کنترل: /start — پنل مالک (ساخت/لیست/خاموش/حذف لایسنس) یا ورود با لایسنس""",
    "echo": """🔁 Echo و ابزارهای روزمره\\n{p}echo add|del [@user|id] (یا Reply)\\n{p}echo list [all] | clear [allchats] | on|off | status\\n{p}echo edit on|off  (ادیت به «اکو از ...»)\\n{p}echo wipe on|off  (پاک‌کردن پیام اکوکننده)\\nکاربر مجاز: «اکو سلام» (Reply = ریپلای روی همان پیام)\\n{p}msginfo (Reply روی پیام)  ← نشان می‌دهد اکو بوده یا نه\\n{p}repeat on|off [@user|id] (یا Reply) | list [all] | status | clear [allchats] | pause|resume  ← هر پیامش را عیناً Reply می‌کنم (فقط همان گپ)\\n{p}todo add|list|done|undone|del|clear\\n{p}conv 100 usd [toman]  (دلار/یورو/تومان/کریپتو)\\n{p}ping\\n{p}copy [me|@chat]  (Reply)\\n{p}backup  (دیتابیس → Saved Messages)""",
    "plus": """✨ Hāpoyi Plus (۱۵ قابلیت)\n{p}timer 5m [10s] [متن] (عدد دوم = هر چند ثانیه ادیت) | {p}timer stop\n{p}fake typing|voice|video|round|game|photo|file|sticker|location|contact [30s|10m|inf] (بدون زمان = نامحدود)\n{p}fake list | {p}stop fake [نوع] | {p}stop fake all\n{p}unit 5 km mi\n{p}greet on|off|set <متن>|status\n{p}dnd 23:00-07:00 [متن] | {p}dnd off|status\n{p}bday add <نام> <ماه-روز> | list | del <id>\n{p}spend 50k غذا ناهار | today|week|month|list|undo|del <id>\n{p}habit add <نام> | done <id> | list | del <id>\n{p}snip add <نام> <متن> | {p}snip <نام> | list | del <نام>\n{p}fancy bold|italic|mono|script|fraktur|circle|wide|small|flip|strike|under <متن> (یا Reply)\n{p}hash [md5|sha1|sha256|sha512] <متن>\n{p}b64 enc|dec <متن>\n{p}wc (Reply یا متن)\n{p}pomo [کار] [استراحت] | {p}pomo stop\n{p}quote add (Reply) | list | del <id> | {p}quote\n{p}unread [N]\n{p}plus  (همین فهرست)\nداده‌ی همه‌ی این‌ها برای هر اکانت جداست.""",
    "ai": """🤖 هوش مصنوعی (API رایگان با ریست روزانه)\\n{p}ask <سؤال> (یا Reply؛ عکس هم می‌تونی بدی: کپشن `{p}ask ...` یا Reply روی عکس → مدل بیننده خودکار انتخاب می‌شه)\\n{p}web <سؤال>  (جستجوی اینترنت + خواندن بهترین صفحه‌ها + جواب با منبع؛ با هر API کار می‌کنه)\\n{p}imagine <توضیح>  (ساخت عکس؛ {p}img و {p}draw هم)\\n{p}sum [N|30m|2h]  خلاصهٔ گپ\\n{p}tr [fa|en|ar|...] [متن] (یا Reply) | {p}trauto on [lang]|off|list|clear (Reply)\\n{p}stt (Reply روی ویس) | {p}tts [fa|en|...] [male] <متن>\\n{p}ai status | {p}ai afk on|off | {p}ai persona <لحن>\\n{p}reply <id> <متن>  (هر پیام AI یک شناسه دارد مثل #13345؛ با شناسه یا با Reply روی آن پیام AI ادامهٔ همان گفتگو را می‌گیری و جواب زیر همان پیام می‌آید)\\n{p}ask (Reply روی پیام AI = ادامهٔ همان گفتگو؛ Reply روی پیام یک نفر دیگر = اول آن پیام را می‌خواند؛ {p}ask خالی فقط با Reply کار می‌کند؛ {p}ask -n متن = بدون حافظه)\\n{p}storage on|off|status|list|clear [all]  (حافظهٔ AI؛ خود {p}storage = فضای دیسک سرور: روشن = ۵۰۰۰ پیام برای همیشه + ادامهٔ خودکار گفتگوی هر گپ؛ خاموش = ۶۰ پیام / ۳ روز)\\n{p}do <درخواست به زبان خودت> | {p}act | {p}agent  (AI خودش دستورهای سلف را با اکانت تو می‌فرستد: «هر ۵ دقیقه بنویس میو» ← .every 5m میو؛ دانلود با کیفیت، تایمر، اتو ریپلای، فیک … همه؛ دفعهٔ اول اجازهٔ دائمی می‌پرسد)\\n{p}apikey add <کلید> | add <سرویس> <کلید> | custom <base> <کلید> | list | del <سرویس> <n|۴حرف|all> | test  (کلید API بدون دست‌زدن به .env؛ فقط اکانت مالک؛ رمزنگاری‌شده؛ پیام حاوی کلید فوراً ویرایش می‌شود)\\n{p}ai control on|off|status|log | {p}ai control danger on|off  (دستورهای حساس مثل بن و پاک‌کردن پیام هر بار «بله» می‌خوان) | {p}ai yes | {p}ai no\\n{p}models  (پنل شیشه‌ای انتخاب مدل: 🧠 هوشمند یا یک مدل مشخص، جایگزینی خودکار، لیست زندهٔ مدل‌های هر سرویس، تست)  | {p}models list|refresh|status | {p}model auto | {p}model <شماره|اسم> | {p}model fallback on|off | {p}model strategy balanced|ordered\\n{p}guide <سؤال دربارهٔ سلف>  (راهنمای هوشمند؛ هر زبان/مترادفی: «زمان‌بندی»، schedule، تایم مسیج ← .later)  | {p}ask هم وقتی سؤال دربارهٔ سلف باشه همین‌طور جواب می‌ده\\n{p}aiguide on|off|status  (دستیار هوشمند: وقتی گیج/ارور/غلط‌تایپی/خنده‌ای، AI با توجه به موقعیت تصمیم می‌گیره چیزی بگه یا نه؛ خاموش = فقط {p}ask و {p}guide)\\n{p}aiguide tips on|off (نکته‌های فوری بدون توکن: لینک یوتیوب/اینستا/تیک‌تاک ← dl، «یادم بنداز» ← remind، «قیمت دلار» ← price ...) | {p}aiguide fun on|off | where chat|saved | ttl <ثانیه> | here on|off | ctx on|off\\n{p}aiknow add عنوان | متن | list | show <id> | del <id> | import (Reply روی txt/md) | clear confirm  (فقط اکانت مالک؛ همهٔ اکانت‌ها ازش استفاده می‌کنن)\\nکلید (هر تعداد): GROQ / CEREBRAS / GEMINI / NVIDIA / SAMBANOVA / MISTRAL / OPENROUTER به‌شکل X_API_KEY و X_API_KEY_2 ... در .env؛ وقتی سهمیهٔ یکی تموم شد خودکار بعدی، و وقتی همه تموم شد می‌گه کی برمی‌گرده""",
    "groupguard": """🛡 گروه‌داری پیشرفته\\n{p}captcha on [ثانیه]|off|status  (عضو جدید باید جمع ساده جواب بده)\\n{p}blacklist add|del|list|on|off|sweep  (بن خودکار در همهٔ گروه‌هایت)\\n{p}activity [7d|24h]  (۱۰ نفر فعال + شلوغ‌ترین ساعت)\\n{p}delmes N  (پاک‌کردن N پیام آخر)""",
    "shortcuts": """🧩 میانبر و سفارشی‌سازی\\n{p}start  (راهنمای شروع)\\n{p}macro add <نام> cmd1 ;; cmd2 | run <نام> | {p}m <نام> | list | del\\n{p}alias add <کلمه> <دستور> | list | del  (مثلاً {p}بن {p}خلاصه {p}ترجمه)\\n{p}disable <دستور> [all] | {p}enable <دستور> | {p}disabled\\n{p}health [all] | {p}autobackup on|off|now | {p}restore""",
    "channels": """📢 Channels\n{p}comment <channel> <text>\n{p}comment first <channel> <text>  (کامنت اول خودکار زیر هر پست جدید)\n{p}comment first off|on|del <channel> / list\n{p}comments <channel> <post_id>""",
}


def _text(section: str) -> str:
    """Section text with the real prefix and real new lines (some sections were written with a literal backslash-n)."""
    return section.replace("\\n", "\n").format(p=PREFIX)


def _build_help() -> str:
    out = ["HĀPOYI USERBOT — COMPLETE HELP", "", "Control Center: .menu  (داشبورد + اکشن‌های زنده: AFK، every، AutoReply، Todo، عادت‌ها، بکاپ، ...)", ""]
    for key, section in SECTIONS.items():
        out.append(f"===== {key.upper()} =====")
        out.append(_text(section))
        out.append("")
    out.append("Notes:")
    out.append("- UserBot uses MTProto/Telethon; Assistant Bot provides the button UI.")
    out.append("- Casino smart mode is rate-limited and stops on flood/slow-mode conditions.")
    out.append("- Friend/Enemy replies use a per-user/per-chat cooldown to avoid message storms.")
    return "\n".join(out) + "\n"


def setup(client, db):
    HELP_FILE.parent.mkdir(exist_ok=True)
    HELP_FILE.write_text(_build_help(), encoding="utf-8")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}help(?:\s+(\w+))?$"))
    async def _help(event):
        section = event.pattern_match.group(1)
        if section and section.lower() in SECTIONS:
            await event.reply(_text(SECTIONS[section.lower()]))
            return
        await client.send_file(event.chat_id, HELP_FILE, caption="🧩 Hāpoyi UserBot — Help.txt")
        try:
            await event.delete()
        except Exception:
            pass
