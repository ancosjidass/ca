# 1.17.2 — `.do` runs every command

ROOT CAUSE (found in Telethon 1.45 source): messages that THIS session sends with send_message() are never dispatched to
NewMessage handlers (their updates are flagged `_self_outgoing`). So a command sent by `.do` was only text; no handler ever ran it,
while the same text typed by hand worked. Fix: `.do` now hands every sent command to the command handlers itself
(modules/ai_agent.py `feed_handlers`); tested with real Telethon Event objects.

Other problems: `.do` showed the right command (e.g. `.ban`, `.mute`, `.blacklist`) but did not run it — the "sensitive" list
(CONFIRM) made the AI wait for a «بله» that never reached it, other commands were refused (BLOCKED / «دستور ناشناخته»).

Changes
- The ONE-TIME permission question stays: until the owner answers «بله» (or `.ai control on`) nothing runs; if it is not answered, every next `.do` asks again.
- Sensitive commands run at once. `.ai control danger on` brings the «بله» question back (opt-in).
- BLOCKED list is only `.do/.act/.agent` (a `.do` inside `.do` would loop forever). `.lic .backup .restore .macro .alias .protect .apikey .ai control ...` all work.
- A command is "known" when it is in the docs OR has a real handler in the running bot (`blacklist`, `roll`, `slots`, `muted`, ... no longer «ناشناخته»).
- Commands that act on a person/message (ban, mute, warn, promote ...) are always sent as a Reply to the replied message, whatever `on_reply` the model said.
- The model gets a bigger manual (11k chars) + the names of undocumented commands; limits raised: 12 actions per request, 30 requests per minute.

## Numeric id / "invalid username or id" (same release)
- `resolve_target` cleans what it gets: Persian digits, `@123456789`, `tg://user?id=`, `t.me/name`, hidden direction marks, quotes/backticks, trailing `.`/`،`.
- A numeric id Telegram does not know yet is looked up in the member lists of the chat (all, banned, muted, admins) - this also makes `.unban <id>` of a banned user work.
- `ban/mute/kick/unban...` (core/actions.edit_banned) use the same fallback and say clearly "not found in this group" instead of crashing.
- Store-only commands (`.whitelist`, `.blacklist add`, `.echo add`, `.relation`, `.autoreact`, `.repeat`, autodelete) keep the id even when Telegram cannot resolve it.
- `.do` cleans the model's command text before sending (id-like words after ban/mute/blacklist ... only; message texts are never touched).
