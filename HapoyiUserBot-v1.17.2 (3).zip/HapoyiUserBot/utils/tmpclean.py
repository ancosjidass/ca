"""Server-side temporary files: tracked, always removed, and swept when a crash left something behind.

* `new_workdir()` / `workdir()` make a private folder under data/media (or data/dl, ...) and register it as ACTIVE;
* `release(path)` deletes it (also when the upload failed) and un-registers it;  `purge(...)` deletes single files / folders
  at once - e.g. right after a file went to Telegram, long before the rest of an album is finished;
* `sweep(base, max_age)` deletes everything under `base` that is NOT active and has not been touched for `max_age` seconds
  (leftovers of a killed process, an exception between download and cleanup, ...). Active work dirs are never touched.
"""
from __future__ import annotations

import logging
import os
import shutil
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

log = logging.getLogger(__name__)
DATA_DIR = Path(__file__).resolve().parents[1] / "data"
MEDIA_DIR = DATA_DIR / "media"
DL_DIR = DATA_DIR / "dl"
CLONE_DIR = DATA_DIR / "clone_tmp"
SWEEP_DIRS = (MEDIA_DIR, DL_DIR, CLONE_DIR)
_ACTIVE: set[str] = set()


def _real(path: str | os.PathLike) -> str:
    return os.path.realpath(os.fspath(path))


def size_of(path: str | os.PathLike) -> int:
    p = Path(path)
    try:
        if p.is_file():
            return p.stat().st_size
        return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
    except OSError:
        return 0


def new_workdir(base: str | os.PathLike | None = None, prefix: str = "w_") -> str:
    base_dir = Path(base) if base else MEDIA_DIR
    base_dir.mkdir(parents=True, exist_ok=True)
    path = tempfile.mkdtemp(dir=base_dir, prefix=prefix)
    _ACTIVE.add(_real(path))
    return path


def purge(*paths: str | os.PathLike | None) -> int:
    """Delete files / folders now. Missing paths are fine. Returns the bytes freed."""
    freed = 0
    for p in paths:
        if not p:
            continue
        try:
            freed += size_of(p)
            if Path(p).is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                os.remove(p)
        except FileNotFoundError:
            pass
        except OSError as exc:
            log.debug("tmp purge %s: %s", p, exc)
    return freed


def release(path: str | os.PathLike | None) -> int:
    """Delete a work dir and stop tracking it (safe to call twice)."""
    if not path:
        return 0
    _ACTIVE.discard(_real(path))
    return purge(path)


@contextmanager
def workdir(base: str | os.PathLike | None = None, prefix: str = "w_") -> Iterator[str]:
    path = new_workdir(base, prefix)
    try:
        yield path
    finally:
        release(path)


def is_active(path: str | os.PathLike) -> bool:
    real = _real(path)
    return any(real == a or real.startswith(a + os.sep) or a.startswith(real + os.sep) for a in _ACTIVE)


def _newest_mtime(path: Path) -> float:
    try:
        newest = path.stat().st_mtime
        if path.is_dir():
            for f in path.rglob("*"):
                try:
                    newest = max(newest, f.stat().st_mtime)
                except OSError:
                    pass
        return newest
    except OSError:
        return time.time()


def sweep(base: str | os.PathLike, max_age: float, now: float | None = None) -> tuple[int, int]:
    """(items removed, bytes freed): everything directly under `base` that is idle for > max_age seconds and not active."""
    now = now or time.time()
    root = Path(base)
    removed = freed = 0
    if not root.is_dir():
        return 0, 0
    for child in root.iterdir():
        try:
            if is_active(child) or now - _newest_mtime(child) < max_age:
                continue
            freed += purge(child)
            removed += 1
        except OSError:
            continue
    return removed, freed


def sweep_all(max_age: float) -> tuple[int, int]:
    removed = freed = 0
    for base in SWEEP_DIRS:
        r, f = sweep(base, max_age)
        removed, freed = removed + r, freed + f
    return removed, freed


def free_mb(path: str | os.PathLike | None = None) -> float:
    target = Path(path or DATA_DIR)
    while not target.exists() and target != target.parent:
        target = target.parent
    try:
        return shutil.disk_usage(target).free / 1048576
    except OSError:
        return float("inf")


def usage() -> dict[str, int]:
    return {d.name: size_of(d) for d in SWEEP_DIRS if d.exists()}
