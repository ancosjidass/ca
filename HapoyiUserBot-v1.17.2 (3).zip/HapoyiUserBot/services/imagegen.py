"""Text -> image.  `.imagine <description>`

Backends, first that works wins:
  1. AI_IMAGE_BASE / AI_IMAGE_KEY(S) / AI_IMAGE_MODEL   any OpenAI-style  POST {base}/images/generations  (OpenAI, Together, ...)
  2. Gemini  (your GEMINI keys; model GEMINI_IMAGE_MODEL, default gemini-2.5-flash-image)  through its OpenAI-compatible endpoint
     - image generation on the Gemini free tier is limited / may not be included for your account: then it is skipped on its own
  3. Pollinations  no key, free (https://image.pollinations.ai); AI_IMAGE_POLLINATIONS=off disables it
Result: image bytes (kept in memory, nothing is written to the server disk).
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
from urllib.parse import quote

import aiohttp

from services import ai

log = logging.getLogger(__name__)
TIMEOUT = aiohttp.ClientTimeout(total=120)
MAX_BYTES = 12 * 1024 * 1024


class ImageError(Exception):
    pass


def _is_image(data: bytes) -> bool:
    return data[:3] == b"\xff\xd8\xff" or data[:8] == b"\x89PNG\r\n\x1a\n" or data[:4] == b"RIFF" or data[:6] in {b"GIF87a", b"GIF89a"}


async def _openai_style(sess, base: str, keys: list[str], model: str, prompt: str, tag: str) -> bytes:
    last = "no key"
    for i, key in enumerate(keys):
        park = f"img-{tag}" if i == 0 else f"img-{tag}#{i + 1}"
        if ai.PARKED.get(park, (0, ""))[0] > __import__("time").time():
            continue
        payload = {"model": model, "prompt": prompt[:1500], "n": 1, "response_format": "b64_json"}
        async with sess.post(f"{base}/images/generations", json=payload, headers={"Authorization": f"Bearer {key}"}) as r:
            body = await r.text()
            if r.status == 200:
                try:
                    item = (json.loads(body).get("data") or [{}])[0]
                except ValueError as exc:
                    raise ImageError("bad response") from exc
                if item.get("b64_json"):
                    data = base64.b64decode(item["b64_json"])
                elif item.get("url"):
                    async with sess.get(item["url"]) as img:
                        data = await img.content.read(MAX_BYTES)
                else:
                    raise ImageError("no image in response")
                if not _is_image(data):
                    raise ImageError("response is not an image")
                return data
            until, why, _kind = ai.classify_ex(r.status, r.headers, body)
            ai.park(park, until, why)
            last = f"{tag}: {why}"
    raise ImageError(last)


async def _pollinations(sess, prompt: str) -> bytes:
    url = f"https://image.pollinations.ai/prompt/{quote(prompt[:800])}?width=1024&height=1024&nologo=true"
    async with sess.get(url, headers={"User-Agent": "Mozilla/5.0"}) as r:
        data = await r.content.read(MAX_BYTES)
        if r.status != 200 or not _is_image(data):
            raise ImageError(f"pollinations http {r.status}")
        return data


async def generate(prompt: str, session: aiohttp.ClientSession | None = None) -> tuple[bytes, str]:
    """(image bytes, backend name). Raises ImageError with a short reason when every backend failed."""
    env = os.environ
    own = session is None
    sess = session or aiohttp.ClientSession(timeout=TIMEOUT)
    errors: list[str] = []
    try:
        base = (env.get("AI_IMAGE_BASE") or "").strip().rstrip("/")
        keys = ai.collect_keys(env, "AI_IMAGE")
        if base and keys:
            try:
                return await _openai_style(sess, base, keys, env.get("AI_IMAGE_MODEL") or "dall-e-3", prompt, "custom"), "custom"
            except (ImageError, aiohttp.ClientError, asyncio.TimeoutError, ValueError) as exc:
                errors.append(str(exc) or exc.__class__.__name__)
        gem = ai.provider_keys("gemini")
        if gem:
            try:
                return await _openai_style(sess, ai.PROVIDERS["gemini"].base, gem, env.get("GEMINI_IMAGE_MODEL") or "gemini-2.5-flash-image",
                                           prompt, "gemini"), "gemini"
            except (ImageError, aiohttp.ClientError, asyncio.TimeoutError, ValueError) as exc:
                errors.append(str(exc) or exc.__class__.__name__)
        if (env.get("AI_IMAGE_POLLINATIONS") or "on").strip().lower() not in {"off", "0", "false", "no"}:
            try:
                return await _pollinations(sess, prompt), "pollinations"
            except (ImageError, aiohttp.ClientError, asyncio.TimeoutError, ValueError) as exc:
                errors.append(str(exc) or exc.__class__.__name__)
    finally:
        if own:
            await sess.close()
    raise ImageError("; ".join(errors) or "no image backend is enabled")
