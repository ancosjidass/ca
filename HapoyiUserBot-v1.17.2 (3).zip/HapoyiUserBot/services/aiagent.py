"""AI account control ("agent") - the pure part (1.17.0). No Telegram here, so every rule can be tested.

`.do <request in your own words>` -> the AI turns it into EXACT commands of the self -> the bot sends them from your account,
as if you had typed them (so every feature of the self works: .every .dl .autoreply .fake .timer ...).

1.17.2: EVERY command of the self can be sent by `.do` - typing `.do` is the owner's permission.
    BLOCKED   only the agent itself (`.do` inside `.do` would loop forever)
    CONFIRM   the "sensitive" list; by default NOT asked any more (ban, mute, blacklist, purge ... run at once).
              `.ai control danger on` brings the «بله» question back for people who want it.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from services import knowledge as K

MAX_ACTIONS = 12
MAX_CMD_CHARS = 1500
MAX_TEXT_CHARS = 3500
PENDING_TTL = 180          # seconds the AI waits for «بله» / «نه»
MAX_REQUESTS_PER_MIN = 30
SEND_GAP = 0.8             # seconds between two sent commands (no flood)

# Never executed by the AI, whatever the model says or the user's text contains.
BLOCKED: dict[str, str] = {
    "do": "خود دستور AI", "act": "خود دستور AI", "agent": "خود دستور AI",   # only to prevent an endless loop
}
# Sent only after an explicit yes (they hurt people / delete things / give others power over the account).
CONFIRM = frozenset({
    "ban", "unban", "kick", "mute", "unmute", "warn", "unwarn", "purge", "delmes", "del", "delall", "mesdel", "cleanme", "reactdel",
    "promote", "demote", "autoban", "autodelete", "blacklist", "captcha", "lock", "unlock", "slowmode", "linkguard", "filter", "flood",
    "rate", "echo", "clone", "unclone", "whitelist", "leave",
})
# These act on the message the user replied to; when the user used `.do` as a Reply they are sent as a reply to the same message.
REPLY_DEFAULT = frozenset({
    "ban", "unban", "kick", "mute", "unmute", "warn", "unwarn", "warnings", "del", "pin", "promote", "demote", "ss", "sticker", "gif",
    "rename", "resize", "watermark", "download", "tr", "stt", "save", "react", "msginfo", "clone", "delafter", "copy", "fancy",
    "wc", "quote", "delall", "userinfo", "echo", "friend", "enemy", "autoreact", "casino", "dice", "dart", "bowling", "basket", "football",
})
DEFAULT_SECTIONS = ("power", "plus", "automation", "personal", "dl", "media")

YES_WORDS = frozenset({"بله", "آره", "اره", "ارع", "باشه", "تایید", "تایید میکنم", "تایید می کنم", "اجازه میدم", "اجازه می دم", "اجازه دارید", "موافقم",
                       "انجام بده", "اوکی", "اکی", "yes", "y", "ok", "okay", "allow", "confirm", "sure"})
NO_WORDS = frozenset({"نه", "خیر", "نخیر", "لغو", "نمیخوام", "نمی خوام", "بیخیال", "no", "n", "cancel", "deny", "stop"})

_URL = re.compile(r"https?://[^\s<>\"')]+", re.I)


def norm_word(text: str | None) -> str:
    t = K.norm(text or "")
    t = re.sub(r"[^\w\s]", "", t, flags=re.U)
    return re.sub(r"\s+", " ", t).strip()


def is_yes(text: str | None) -> bool:
    return norm_word(text) in {norm_word(w) for w in YES_WORDS}


def is_no(text: str | None) -> bool:
    return norm_word(text) in {norm_word(w) for w in NO_WORDS}


def extract_urls(text: str | None, limit: int = 3) -> list[str]:
    seen: list[str] = []
    for m in _URL.finditer(text or ""):
        u = m.group(0).rstrip(".,;)")
        if u not in seen:
            seen.append(u)
        if len(seen) >= limit:
            break
    return seen


@dataclass
class Action:
    kind: str              # "cmd" | "text"
    text: str
    name: str = ""         # command name (cmd only)
    chat: str = "here"     # "here" | "saved"
    on_reply: bool = False
    risky: bool = False


@dataclass
class Plan:
    reply: str = ""
    clarify: str = ""
    actions: list[Action] = field(default_factory=list)
    rejected: list[tuple[str, str]] = field(default_factory=list)  # (what, why)

    @property
    def risky(self) -> bool:
        return any(a.risky for a in self.actions)


_INVISIBLE = re.compile("[\u200b\u200e\u200f\u202a-\u202e\u2060\u2066-\u2069\ufeff]")
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_IDLIKE = re.compile(r"^@?([0-9۰-۹٠-٩]{3,16})$")


PERSON_COMMANDS = frozenset({"ban", "unban", "kick", "mute", "unmute", "warn", "unwarn", "warnings", "promote", "demote", "blacklist", "whitelist",
                             "echo", "friend", "enemy", "relation", "autoreact", "clone", "userinfo", "autodelete", "autoban", "repeat", "mirror",
                             "tag", "userinfo", "info", "id"})


def clean_command(cmd: str, prefix: str = ".") -> str:
    """What the model writes is not always what the self parses: hidden direction marks, Persian digits in an id, `@123456789`
    (an @ in front of a numeric id), backticks around the command. ZWNJ (needed by Persian text) is kept."""
    c = _INVISIBLE.sub("", (cmd or "")).replace("\u00a0", " ").strip().strip("`").strip()
    parts = c.split(" ")
    head = (parts[0][len(prefix):] if parts and parts[0].startswith(prefix) else "").lower().split("@", 1)[0]
    if head not in PERSON_COMMANDS:
        return c
    for i in range(1, min(len(parts), 4)):  # only the first words after the command can be the person
        m = _IDLIKE.match(parts[i].strip("`'\"“”.,،؛:!؟()[]<>"))
        if m:
            parts[i] = m.group(1).translate(_DIGITS)
    return " ".join(parts)


def command_name(cmd: str, prefix: str) -> str:
    m = re.match(rf"\s*{re.escape(prefix)}(\S+)", cmd or "")
    return (m.group(1).lower() if m else "").split("@", 1)[0]


def check_command(cmd: str, prefix: str, known: set[str]) -> tuple[str, str, bool]:
    """(name, refusal reason or "", needs_confirmation)."""
    cmd = (cmd or "").strip()
    name = command_name(cmd, prefix)
    if not cmd.startswith(prefix) or not name:
        return name, "این یک دستور نیست", False
    if len(cmd) > MAX_CMD_CHARS:
        return name, "خیلی طولانی", False
    if name in BLOCKED:
        return name, f"AI اجازهٔ اجرای این دستور را ندارد ({BLOCKED[name]})", False
    if known and name not in known:
        return name, "دستور ناشناخته", False
    args = cmd[len(prefix) + len(name):].split()
    first = args[0].lower() if args else ""
    risky = name in CONFIRM
    if name == "storage" and first == "clear":
        risky = True
    if name == "every" and first in {"del", "delete", "rm", "stop"} and (len(args) > 1 and args[1].lower() in {"all", "allchats"}):
        risky = True
    return name, "", risky


def validate_plan(data: dict[str, Any] | None, prefix: str, known: set[str], *, has_reply: bool = False) -> Plan:
    plan = Plan()
    if not isinstance(data, dict):
        return plan
    plan.reply = str(data.get("reply") or "").strip()[:700]
    plan.clarify = str(data.get("clarify") or "").strip()[:400]
    raw = data.get("actions")
    items = raw if isinstance(raw, list) else []
    for item in items:
        if len(plan.actions) >= MAX_ACTIONS:
            plan.rejected.append((str(item)[:60], f"حداکثر {MAX_ACTIONS} کار در هر درخواست"))
            continue
        if isinstance(item, str):
            item = {"cmd": item}
        if not isinstance(item, dict):
            continue
        chat = "saved" if str(item.get("chat") or "").lower() in {"saved", "me", "self"} else "here"
        cmd, txt = item.get("cmd"), item.get("text")
        if isinstance(cmd, str) and cmd.strip():
            cmd = clean_command(cmd, prefix)
            name, why, risky = check_command(cmd, prefix, known)
            if why:
                plan.rejected.append((cmd.strip()[:80], why))
                continue
            flag = item.get("on_reply")
            if isinstance(flag, str):
                flag = flag.strip().lower() in {"true", "1", "yes", "y"}
            # Commands that act on a person/message ALWAYS go out as a Reply to the replied message (the model forgetting
            # or answering false must never turn «.ban» into a command without a target).
            on_reply = has_reply and (name in REPLY_DEFAULT or bool(flag))
            plan.actions.append(Action("cmd", cmd.strip(), name, chat if not on_reply else "here", on_reply, risky))
        elif isinstance(txt, str) and txt.strip():
            t = txt.strip()
            if t.startswith(prefix):
                plan.rejected.append((t[:80], "متن عادی نباید با پیشوند دستور شروع شود (از cmd استفاده کن)"))
            elif is_yes(t) or is_no(t):
                plan.rejected.append((t[:80], "متن تأیید/لغو فرستاده نمی‌شود"))
            elif len(t) > MAX_TEXT_CHARS:
                plan.rejected.append((t[:80], "متن خیلی طولانی"))
            else:
                plan.actions.append(Action("text", t, "", chat, bool(item.get("on_reply")) and has_reply, False))
    return plan


# ------------------------------------------------------------------ prompt
SYNTAX_NOTES = """\
SYNTAX NOTES (exact, verified against the code):
- {p}every 5m <text>   repeats <text> in THIS chat every 5 minutes forever (also {p}every <text> 5m). {p}every 10m 5 <text> = at most 5 times. {p}every 10m - <text> when the text starts with a number. Stop: {p}every del all | list: {p}every list. Interval 1s..72h.
- {p}autoreply add <trigger> => <response>   when an incoming message CONTAINS <trigger> the account replies <response>. In a group it applies to that group, in a private chat to all private chats. Also: {p}autoreply list | del <id> | on | off.
- {p}autoreact <emoji>   (as a Reply = only that user, otherwise the whole chat)   {p}autoreact off
- {p}later 10m <text> = one message sent later;  {p}remind 10m <text> = reminder;  {p}timer 5m [10s] [text];  {p}selfdestruct 30s <text>
- {p}dl [mp4|mp3|360|480|720|1080|4k|best|me] <link>   (quality / format / send to Saved Messages first, then the link). {p}dl info <link> = details only.
- {p}fake typing|voice|video|round|game|photo|file|sticker|location|contact [30s|10m|inf]   stop: {p}stop fake all
- {p}afk <reason> / {p}back ; {p}note add <name> <text> ; {p}todo add <text> ; {p}bday add <name> <MM-DD>
Durations are written like 30s, 5m, 2h, 1d."""


def manual_for(request: str, budget: int = 11000, extra: tuple[str, ...] = ()) -> str:
    """The docs sections that matter for this request (best match first) within a size budget + a map of every other command."""
    scores = [k for k, _ in K.score_sections(request)]
    order = scores + [k for k in DEFAULT_SECTIONS if k not in scores] + [k for k in K.sections() if k not in scores and k not in DEFAULT_SECTIONS]
    parts: list[str] = []
    rest: list[str] = []
    used = 0
    for key in order:
        text = K.section_text(key, limit=2200)
        if not text:
            continue
        if used + len(text) <= budget or not parts:
            parts.append(text)
            used += len(text)
        else:
            rest.append(f"{key}: " + ", ".join(K.PREFIX + c for c in K.section_commands(key)[:20]))
    out = "\n\n".join(parts)
    if extra:
        rest.append("other: " + ", ".join(K.PREFIX + c for c in extra[:60]))
    if rest:
        out += "\n\n(more commands exist - names only, ask via clarify if you need their syntax)\n" + "\n".join(rest)
    return out


def build_messages(request: str, *, prefix: str, chat_kind: str, reply_info: dict[str, Any] | None, name: str = "",
                   extra_commands: tuple[str, ...] = ()) -> list[dict[str, str]]:
    reply_line = "no"
    if reply_info:
        reply_line = f"yes (a {reply_info.get('kind', 'message')} from {reply_info.get('who', '?')}"
        urls = reply_info.get("urls") or []
        reply_line += (", links in it: " + " ".join(urls)) if urls else ""
        reply_line += ")"
    system = (
        "You are the control brain of «Hāpoyi», a Telegram self-bot that runs on the user's OWN account"
        f"{' (' + name + ')' if name else ''}. The user describes in natural language (any language, dialect or slang) what they want; you turn it "
        "into EXACT commands of the self. The bot then sends those commands from the user's account as if the user had typed them.\n"
        'Reply with ONLY one JSON object: {"reply": "...", "actions": [...], "clarify": ""}\n'
        '- "reply": one or two short friendly sentences, in the user\'s language (Persian if unsure), saying what you set up.\n'
        '- "actions": at most 12 items, in a sensible order. A command: {"cmd": "<one full command with the prefix>"}. '
        'Add "on_reply": true when the command must act on the message the user replied to (ban, ss, tr ...); add "chat": "saved" to run it in Saved Messages. '
        'If the account itself must write plain text: {"text": "..."}.\n'
        '- "clarify": ONE short question when an essential detail is missing (a link, a duration, which person); then "actions" stays empty.\n'
        "Rules:\n"
        f'1. Use ONLY commands of the MANUAL below with the exact syntax shown; the prefix is "{prefix}". Never invent commands or options.\n'
        "2. If the request is only a question or chat, answer it in \"reply\" and leave actions empty.\n"
        "3. A person can be named by @username / id in the command, or is the author of the replied message. Replied message present: " + reply_line + ". "
        "When a command needs a message or a person and there is none, ask with clarify instead of guessing.\n"
        f"4. Current chat: {chat_kind}.\n"
        f"5. The user is the owner of the account and has given permission for EVERY command of the MANUAL (ban, mute, blacklist, purge, promote, ...): "
        f"never refuse, never ask for confirmation, just produce the command. Only {prefix}do itself is not allowed (it would loop).\n"
        "6. A person given as a numeric id is written as the plain digits (e.g. 123456789) - never with @ and never in Persian digits. A command that needs a person: if the user replied to a message use the command without a target and add \"on_reply\": true; "
        "otherwise put @username or the numeric id in the command.\n\n"
        + SYNTAX_NOTES.replace("{p}", prefix) + "\n\n=== MANUAL ===\n" + manual_for(request, extra=extra_commands)
    )
    return [{"role": "system", "content": system}, {"role": "user", "content": request[:2500]}]


def parse_plan(text: str | None, prefix: str, known: set[str] | None = None, *, has_reply: bool = False) -> Plan | None:
    data = K.parse_json(text or "")
    if data is None:
        return None
    return validate_plan(data, prefix, known if known is not None else (K.known_commands() | {"storage", "reply"}), has_reply=has_reply)
