"""1.13.0: XO join + random start, emoji screenshots, timer/fake parsing, Repeat, Report."""
from __future__ import annotations

import asyncio
import pathlib
import random
import sys
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from core.guard import install_handler_guard  # noqa: E402
from tests.test_regressions import ADMIN, FakeEvent, _dispatch, _find  # noqa: E402
from tests.test_v190 import ALI, HASAN, Env, _db, _echo_event  # noqa: E402


def test_xo_lobby_join_and_random_first_player():
    from modules.xo_duel import XO

    g = XO("t", 1, "A")
    assert not g.started and "Join" in str(g.buttons()[0][0].text) and "جوین" in g.body()
    starters = set()
    for seed in range(30):
        g2 = XO("t", 1, "A", 2, "B", fixed_opp=True)
        starters.add(g2.start(random.Random(seed)))
        assert g2.started and len(g2.buttons()) == 4 and "قرعه" in g2.body()
    assert starters == {"X", "O"}


def test_screenshot_emoji_numbers_and_jumbo():
    from utils.shot import emoji_image, only_emoji, render_message_sticker, visual_runs, wrap, load_font

    assert only_emoji("😀") == ["😀"] and only_emoji("😀 ❤️🔥") == ["😀", "❤️", "🔥"] and only_emoji("😀😀😀😀") is None
    assert only_emoji("123") is None and only_emoji("hi 😀") is None
    for e in ("😀", "❤️", "👍🏽", "🇮🇷", "1️⃣", "👨‍👩‍👧"):
        assert emoji_image(e, 32) is not None, e
    assert [k for k, _ in visual_runs("سلام 😀")].count("e") == 1
    font = load_font(26)
    assert all("😀" not in l or l.count("😀") <= 40 for l in wrap("😀" * 80, font, 200)) and len(wrap("😀" * 80, font, 200)) > 1
    for text in ("😀", "123456", "۱۲۳ سلام 😀 👍🏽", "a 🇮🇷 b", "x" * 50 + "😀"):
        data = render_message_sticker(name="Ali 🔥 ۱۲", text=text, time_text="12:00", reply_name="R 😎", reply_text="۱ 😀")
        assert data[:4] == b"RIFF"


def test_timer_and_fake_commands():
    from modules import plus

    async def run():
        db = await _db()
        c = Env(ADMIN).c
        c.get_input_entity = lambda x: _coro(object())
        await plus.setup(c, db)
        _, fake = _find(c, "fake")
        _, stop = _find(c, "stop_fake")
        ev = FakeEvent(c, ".fake typing")
        ev.pattern_match = SimpleNamespace(group=lambda i: {1: "typing", 2: None}[i])
        await fake(ev)
        assert ev.deleted
        await asyncio.sleep(0.05)
        fakes = c._hapoyi_fake_stop_all.__closure__  # noqa: F841  (state lives in the module closure)
        ev2 = FakeEvent(c, ".fake typing 20m")  # > 10 minutes is allowed now
        ev2.pattern_match = SimpleNamespace(group=lambda i: {1: "voice", 2: "20m"}[i])
        await fake(ev2)
        assert ev2.deleted and not ev2.replies
        assert await c._hapoyi_fake_stop_all() == 2
        st = FakeEvent(c, ".stop fake all")
        st.pattern_match = SimpleNamespace(group=lambda i: "all")
        await stop(st)
        assert "همهٔ فیک" in st.replies[0]

    asyncio.run(run())


async def _coro(v):
    return v


def test_repeat_scope_exact_copy_and_no_self_command_execution():
    from modules import admin, mirror

    async def run():
        env = Env(ADMIN)
        db = await _db()
        install_handler_guard(env.c)
        admin.setup(env.c, db)
        mirror.COOLDOWN = 0.0
        mirror.setup(env.c, db)
        on = FakeEvent(env.c, ".repeat on", reply_user=ALI, chat_id=-1001)
        on.pattern_match = None
        await _dispatch(env.c, "repeat_cmd", on)
        assert "روشن شد" in on.replies[0]
        _, watcher = _find(env.c, "repeat_watcher")

        # chat A: repeated as a reply to HIS message, exact same message object
        ev = _echo_event(env.c, "سلام", chat_id=-1001)
        ev.id = 41
        await watcher(ev)
        chat, msg, kw = env.sent[0]
        assert chat == -1001 and msg is ev.message and kw["reply_to"] == 41
        # chat B (I am a member there too): nothing
        evb = _echo_event(env.c, "سلام", chat_id=-1002)
        await watcher(evb)
        assert len(env.sent) == 1
        # somebody else: nothing
        await watcher(_echo_event(env.c, "سلام", sender=HASAN, chat_id=-1001))
        assert len(env.sent) == 1

        # he types a self command: sent, but never executed
        fired = []
        orig = env.c.send_message

        async def racing(chat, m, **kw):
            out = FakeEvent(env.c, getattr(m, "message", m), out=True, sender_id=100, chat_id=chat)
            out.id = 7777
            fired.append(env.c._hapoyi_echo_check(out))
            return await orig(chat, m, **kw)

        env.c.send_message = racing
        cmdev = _echo_event(env.c, ".ban", chat_id=-1001)
        cmdev.raw_text = ".ban"
        await watcher(cmdev)
        assert fired == [True]

        # list / pause / off / clear
        lst = FakeEvent(env.c, ".repeat list", chat_id=-1001)
        lst.pattern_match = None
        await _dispatch(env.c, "repeat_cmd", lst)
        assert "Ali" in lst.replies[0]
        n = len(env.sent)
        for word, text in (("pause", None), ("resume", None)):
            e = FakeEvent(env.c, f".repeat {word}", chat_id=-1001)
            await _dispatch(env.c, "repeat_cmd", e)
            if word == "pause":
                await watcher(_echo_event(env.c, "x", chat_id=-1001))
                assert len(env.sent) == n
        off = FakeEvent(env.c, ".repeat off", reply_user=ALI, chat_id=-1001)
        await _dispatch(env.c, "repeat_cmd", off)
        await watcher(_echo_event(env.c, "again", chat_id=-1001))
        assert len(env.sent) == n
        await _dispatch(env.c, "repeat_cmd", FakeEvent(env.c, ".repeat on", reply_user=ALI, chat_id=-1001))
        await _dispatch(env.c, "repeat_cmd", FakeEvent(env.c, ".repeat clear", chat_id=-1001))
        assert (await db.fetchone("SELECT COUNT(*) n FROM repeat_targets"))["n"] == 0

    asyncio.run(run())


def test_report_online_offline_and_restore():
    from modules import report

    async def run():
        db = await _db()
        env = Env(ADMIN)
        c = env.c
        writes = []

        async def call(req):
            if type(req).__name__ == "UpdateProfileRequest":
                writes.append({k: v for k, v in (("about", req.about), ("last_name", req.last_name)) if v is not None})
                return True
            return SimpleNamespace(full_user=SimpleNamespace(about="my real bio"))

        async def get_me():
            return SimpleNamespace(id=100, last_name="Amiri")

        c.__class__ = type("C2", (c.__class__,), {"__call__": lambda self, r: call(r)})
        c.get_me = get_me
        install_handler_guard(c)
        report.setup(c, db)
        await _dispatch(c, "report_cmd", _with(c, ".report on"))
        assert writes[-1] == {"about": "ONLINE"}
        await c._hapoyi_report_offline()
        assert writes[-1] == {"about": "OFFLINE"}
        await _dispatch(c, "report_cmd", _with(c, ".report where name"))
        assert writes[-1] == {"last_name": "Amiri ONLINE"}
        await c._hapoyi_report_offline()
        assert writes[-1] == {"last_name": "Amiri OFFLINE"}
        await _dispatch(c, "report_cmd", _with(c, ".report off"))
        assert writes[-1] == {"last_name": "Amiri"}
        n = len(writes)
        await c._hapoyi_report_offline()
        assert len(writes) == n  # switched off: nothing is written

    asyncio.run(run())


def _with(c, text):
    ev = FakeEvent(c, text)
    ev.pattern_match = SimpleNamespace(group=lambda i: text.split(None, 1)[1] if " " in text else None)
    return ev
