"""1.12.0: .every count/range, screenshot sticker renderer, Plus module (per-account data), RPS duel logic."""
from __future__ import annotations

import asyncio
import io
import pathlib
import sys
import tempfile
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from PIL import Image  # noqa: E402

from core.database import Database  # noqa: E402
from utils import plus_helpers as H  # noqa: E402
from utils import shot  # noqa: E402
from utils.repeatspec import RepeatSpecError, parse_repeat  # noqa: E402


# ============================================================ .every
def test_every_count_tokens_and_range():
    assert parse_repeat("10m 5 hello") == (600, "hello", 5)
    assert parse_repeat("10m x5 hello") == (600, "hello", 5)
    assert parse_repeat("hello 10m") == (600, "hello", None)
    assert parse_repeat("10m - hello") == (600, "hello", None)
    assert parse_repeat("10m ∞ hello") == (600, "hello", None)
    assert parse_repeat("10m - 3 نفر آنلاینن") == (600, "3 نفر آنلاینن", None)  # '-' protects a numeric text
    assert parse_repeat("۱۰m ۵ سلام") == (600, "سلام", 5)
    assert parse_repeat("1s hi") == (1, "hi", None)
    assert parse_repeat("72h hi") == (72 * 3600, "hi", None)
    for bad in ("73h hi", "5d hi", "0.5s hi"):
        with pytest.raises(RepeatSpecError):
            parse_repeat(bad)
    assert parse_repeat("hello") is None and parse_repeat("5m") is None


# ============================================================ screenshot renderer
def test_screenshot_sticker_is_a_valid_512_webp():
    for kw in (dict(name="علی رضایی", text="سلام داداش حالت چطوره؟ " * 6, time_text="21:45", user_id=5),
               dict(name="John", text="hello 🎉 world", theme="light", user_id=7),
               dict(name="X", text="", media_label="[عکس]", user_id=1),
               dict(name="Y", text="x" * 5000, user_id=2, reply_name="Z", reply_text="quoted")):
        data = shot.render_message_sticker(**kw)
        im = Image.open(io.BytesIO(data))
        assert im.format == "WEBP" and max(im.size) == 512 and im.mode in ("RGBA", "RGB")
    assert shot.find_font(False) and shot.find_font(True)
    assert shot.strip_unrenderable("a🎉b") == "a🎉b" and shot.strip_unrenderable("a\x00b") == "ab"  # emoji are drawn now


# ============================================================ helpers
def test_plus_helpers():
    assert H.parse_amount("x") is None and H.parse_amount("۵۰ هزار") == 50000 and H.parse_amount("۵۰هزار") == 50000 and H.parse_amount("2.5m") == 2_500_000
    assert H.fancy("bold", "Ab1") == "𝗔𝗯𝟭" and H.fancy("nope", "x") is None
    assert H.b64("dec", H.b64("enc", "سلام")) == "سلام"
    with pytest.raises(ValueError):
        H.b64("dec", "!!!")
    assert round(H.convert_units(5, "km", "mi"), 3) == 3.107 and H.convert_units(100, "c", "f") == 212 and H.convert_units(1, "kg", "m") is None
    assert H.in_window(60, 23 * 60, 7 * 60) and not H.in_window(600, 23 * 60, 7 * 60)
    assert H.parse_birthday("۱۳۷۵/۰۳/۱۲") == (3, 12, 1375) and H.parse_birthday("13-40") is None


# ============================================================ Plus module: per-account data
class _Ev:
    def __init__(self, text, reply_text=None, chat_id=-1001):
        self.message = SimpleNamespace(message=text, out=True)
        self.raw_text, self.out, self.chat_id, self.is_private = text, True, chat_id, False
        self.is_reply, self._reply_text = reply_text is not None, reply_text
        self.replies, self.edits, self.pattern_match = [], [], None

    async def reply(self, text, **kw):
        self.replies.append(text)

    async def edit(self, text, **kw):
        self.edits.append(text)
        return self

    async def delete(self):
        pass

    async def get_reply_message(self):
        async def sender():
            return SimpleNamespace(first_name="Ali", last_name=None)
        return SimpleNamespace(message=self._reply_text, get_sender=sender)


class _Client:
    def __init__(self):
        self.handlers = []

    def on(self, builder=None):
        def deco(fn):
            self.handlers.append((builder, fn))
            return fn
        return deco

    def is_connected(self):
        return False

    async def send_message(self, *a, **k):
        return SimpleNamespace(id=1)


async def _run(client, ev):
    probe = SimpleNamespace(message=ev.message)
    for builder, fn in client.handlers:
        builder.resolved = True
        if getattr(builder, "pattern", None) is None:
            continue
        if builder.filter(probe) is not None:
            ev.pattern_match = probe.pattern_match
            await fn(ev)
            return ev
    raise AssertionError("no handler matched " + ev.raw_text)


def test_plus_commands_and_account_isolation():
    async def main():
        from modules import plus

        dbs, clients = [], []
        for _ in range(2):
            db = Database(tempfile.mktemp())
            await db.connect()
            c = _Client()
            await plus.setup(c, db)
            dbs.append(db)
            clients.append(c)
        a, b = clients

        assert "ثبت شد" in (await _run(a, _Ev(".spend 50k غذا ناهار"))).replies[0]
        assert "50,000" in (await _run(a, _Ev(".spend today"))).replies[0]
        assert "هزینه‌ای ثبت نشده" in (await _run(b, _Ev(".spend today"))).replies[0]  # other account sees nothing

        await _run(a, _Ev(".habit add ورزش"))
        assert "streak: 1" in (await _run(a, _Ev(".habit done 1"))).replies[0]
        assert "عادتی ثبت نشده" in (await _run(b, _Ev(".habit list"))).replies[0]

        await _run(a, _Ev(".snip add hi سلام دنیا"))
        assert (await _run(a, _Ev(".snip hi"))).edits == ["سلام دنیا"]
        assert "وجود ندارد" in (await _run(b, _Ev(".snip hi"))).replies[0]

        assert "3.1068" in (await _run(a, _Ev(".unit 5 km mi"))).replies[0]
        assert (await _run(a, _Ev(".fancy bold Hi"))).edits == ["𝗛𝗶"]
        assert "کلمه: 2" in (await _run(a, _Ev(".wc سلام دنیا"))).replies[0]
        assert "sha256" in (await _run(a, _Ev(".hash hello"))).replies[0]
        assert "ثبت شد" in (await _run(a, _Ev(".bday add علی 03-12"))).replies[0]
        assert "DND روشن" in (await _run(a, _Ev(".dnd 23:00-07:00 شب بخیر"))).replies[0]
        assert "DND خاموش" in (await _run(b, _Ev(".dnd status"))).replies[0]  # settings are per account too
        assert "ذخیره شد" in (await _run(a, _Ev(".quote add سلام"))).replies[0]
        for db in dbs:
            await db.close()

    asyncio.run(main())


# ============================================================ RPS duel
def test_rps_round_logic_and_scoring():
    from modules.rps_duel import Duel, round_winner

    assert round_winner("r", "s") == 1 and round_winner("s", "r") == 2 and round_winner("p", "p") == 0
    assert round_winner("p", "r") == 1 and round_winner("s", "p") == 1
    g = Duel("t", 1, "A", -1, 5)
    assert g.need == 3 and "A" in g.header()


def test_xo_winner_logic():
    from modules.xo_duel import XO, winner

    assert winner(["X", "X", "X"] + [""] * 6) == "X" and winner(["O", "", "", "", "O", "", "", "", "O"]) == "O"
    assert winner(["X", "O", "X", "X", "O", "O", "O", "X", "X"]) == "D" and winner([""] * 9) is None
    g = XO("t", 1, "A", 2, "B", started=True)
    assert "A" in g.body() and len(g.buttons()) == 4


def test_menu_section_panels_point_to_known_callbacks():
    from modules import ui

    for key, items in ui.SECTION_PANELS.items():
        assert key in ui.SECTIONS
        assert all(data.startswith("ui:") and len(data.encode()) <= 64 for _, data in items)
