from __future__ import annotations

from typing import Any


async def my_id(client: Any) -> int:
    """Return the logged-in account id (cached; get_me() is a network call)."""
    cached = getattr(client, "_hapoyi_me_id", None)
    if cached:
        return int(cached)
    me = await client.get_me()
    client._hapoyi_me_id = int(me.id)
    return int(me.id)


async def my_name(client: Any) -> str:
    cached = getattr(client, "_hapoyi_me_name", None)
    if cached:
        return cached
    me = await client.get_me()
    name = " ".join(x for x in [getattr(me, "first_name", None), getattr(me, "last_name", None)] if x).strip()
    client._hapoyi_me_name = name or getattr(me, "username", None) or "من"
    client._hapoyi_me_id = int(me.id)
    return client._hapoyi_me_name


def owner_flag(client: Any) -> bool:
    """Is this the OWNER's account? True for the main account AND for any account whose Telegram id is HAPOYI_OWNER_ID
    (e.g. the owner's second account that was logged in through the control bot: its kind is "licensed", but it is still him)."""
    flag = getattr(client, "_hapoyi_is_owner", None)
    if flag is not None:
        return bool(flag)
    return getattr(client, "_hapoyi_kind", "main") == "main"


async def is_owner(client: Any) -> bool:
    if owner_flag(client):
        return True
    fleet = getattr(client, "_hapoyi_fleet", None)
    owner = int(getattr(fleet, "owner_id", 0) or 0)
    if owner and int(await my_id(client)) == owner:
        client._hapoyi_is_owner = True
        return True
    return False
